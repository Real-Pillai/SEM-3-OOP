public final class SurgeFeeCalculator {

    private final double minimumSurgePercent;

    public SurgeFeeCalculator(double minimumSurgePercent) {
        this.minimumSurgePercent = minimumSurgePercent;
    }

    final double calculateSurgeFee(double orderValue, int delayMinutes) {
        if (orderValue < 0 || delayMinutes < 0) {
            throw new IllegalArgumentException("orderValue and delayMinutes must be non-negative");
        }
        if (delayMinutes == 0) {
            return 0.0;
        }

        double tieredFee = 0.0;

        int band1 = Math.min(delayMinutes, 5);
        tieredFee += band1 * 0.005 * orderValue;

        if (delayMinutes > 5) {
            int band2 = Math.min(delayMinutes, 15) - 5;
            tieredFee += band2 * 0.01 * orderValue;
        }

        if (delayMinutes > 15) {
            int band3 = delayMinutes - 15;
            tieredFee += band3 * 0.02 * orderValue;
        }

        double floorFee = (minimumSurgePercent / 100.0) * orderValue;

        return Math.max(tieredFee, floorFee);
    }

    public static void main(String[] args) {
        SurgeFeeCalculator calc = new SurgeFeeCalculator(1.0);
        System.out.println("Rs " + calc.calculateSurgeFee(500, 0));
        System.out.println("Rs " + calc.calculateSurgeFee(500, 1));
        System.out.println("Rs " + calc.calculateSurgeFee(500, 16));
    }
}
