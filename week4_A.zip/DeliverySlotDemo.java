import java.util.HashSet;
import java.util.Set;

public class DeliverySlotDemo {

    public static void main(String[] args) {
        System.out.println(new DeliverySlot("ORD101", "13:00-14:00").isPeakHour());
        System.out.println(new DeliverySlot("ORD102").isPeakHour());
    }
}

class DeliverySlot {
    private String orderId;
    private String timeSlot;

    private static final Set<String> PEAK_SLOTS = new HashSet<>();
    static {
        PEAK_SLOTS.add("12:00-13:00");
        PEAK_SLOTS.add("13:00-14:00");
        PEAK_SLOTS.add("19:00-20:00");
        PEAK_SLOTS.add("20:00-21:00");
    }

    public DeliverySlot(String orderId, String timeSlot) {
        this.orderId = orderId;
        this.timeSlot = timeSlot;
    }

    public DeliverySlot(String orderId) {
        this(orderId, "ASAP");
    }

    boolean isPeakHour() {
        return PEAK_SLOTS.contains(timeSlot);
    }
}
