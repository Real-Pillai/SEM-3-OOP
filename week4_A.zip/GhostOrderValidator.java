public class GhostOrderValidator {

    public static void main(String[] args) {
        String[][] rawOrders = {
                {"Ravi", "Paneer Butter Masala"},
                {"", "Chole Bhature"},
                {"Meera", " "},
                {"Divya", "Veg Biryani"}
        };
        processBatch(rawOrders);

        FoodOrder order = new FoodOrder("Ravi", "Paneer Butter Masala");
        order.markDelivered();
        order.markDelivered();
    }

    static void processBatch(String[][] rawOrders) {
        int valid = 0, rejected = 0;
        for (String[] raw : rawOrders) {
            try {
                new FoodOrder(raw[0], raw[1]);
                valid++;
            } catch (IllegalArgumentException e) {
                rejected++;
            }
        }
        System.out.println("Valid: " + valid + " | Rejected: " + rejected);
    }
}

class FoodOrder {
    private String studentName;
    private String dishName;
    private boolean delivered = false;

    public FoodOrder(String studentName, String dishName) {
        if (studentName == null || studentName.trim().isEmpty()) {
            throw new IllegalArgumentException("studentName must not be blank");
        }
        if (dishName == null || dishName.trim().isEmpty()) {
            throw new IllegalArgumentException("dishName must not be blank");
        }
        this.studentName = studentName;
        this.dishName = dishName;
    }

    void markDelivered() {
        if (delivered) {
            System.out.println("Order already marked delivered!");
        } else {
            delivered = true;
            System.out.println("Order marked delivered.");
        }
    }
}
