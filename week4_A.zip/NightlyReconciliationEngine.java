public class NightlyReconciliationEngine {

    public static void main(String[] args) {
        DeliveryAccount[] accounts = {
                new PremiumDeliveryAccount("STU001", 500),
                null,
                new DeliveryAccount("STU002", 300)
        };
        double[] amounts = {500, 400, 300};
        int[] delayMinutesArray = {10, 5, 0};

        processBatch(accounts, amounts, delayMinutesArray);
    }

    static void processAccount(DeliveryAccount account, double amount, int delayMinutes) {
        account.calculateSurgeFee(delayMinutes);
    }

    static void processBatch(DeliveryAccount[] accounts, double[] amounts, int[] delayMinutesArray) {
        int len = Math.min(accounts.length, Math.min(amounts.length, delayMinutesArray.length));

        int processed = 0, nullSkipped = 0, premium = 0, regular = 0;
        double grandTotal = 0.0;

        for (int i = 0; i < len; i++) {
            DeliveryAccount account = accounts[i];
            if (account == null) {
                nullSkipped++;
                continue;
            }
            double fee = account.calculateSurgeFee(delayMinutesArray[i]);
            grandTotal += fee;
            processed++;
            if (account instanceof PremiumDeliveryAccount) {
                premium++;
            } else {
                regular++;
            }
        }

        System.out.println(processed + " processed | " + nullSkipped + " null skipped | " +
                premium + " premium | " + regular + " regular | grand total surge fees = " + grandTotal);
    }
}

class DeliveryAccount {
    private String studentId;
    private double orderValue;

    private static int totalAccountsCreated = 0;
    static {
        totalAccountsCreated = 0;
    }

    public DeliveryAccount(String studentId, double orderValue) {
        this.studentId = studentId;
        this.orderValue = orderValue;
        totalAccountsCreated++;
    }

    public DeliveryAccount(String studentId) {
        this(studentId, 0.0);
    }

    // Simple flat-rate surge fee: 1% of order value per delay minute.
    final double calculateSurgeFee(int delayMinutes) {
        if (delayMinutes <= 0) return 0.0;
        return orderValue * 0.01 * delayMinutes;
    }
}

class PremiumDeliveryAccount extends DeliveryAccount {
    public PremiumDeliveryAccount(String studentId, double orderValue) {
        super(studentId, orderValue);
    }

    public PremiumDeliveryAccount(String studentId) {
        super(studentId);
    }
}
