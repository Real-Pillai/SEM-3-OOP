public class LibraryFineSystem {

    public static void main(String[] args) {
        BookIssue[] issues = new BookIssue[]{
                new BookIssue("Clean Code", "Ravi", 18),
                new BookIssue("Effective Java", "Anu", 5),
                new BookIssue("Refactoring", "Kiran", 0),
                new BookIssue("DSA Handbook", "Priya", 21),
                new BookIssue("Design Patterns", "Suresh", 9)
        };

        for (BookIssue issue : issues) {
            System.out.println(issue.title + " - " + issue.daysOverdue + " days - " +
                    (issue.isSeverelyOverdue() ? "Severely overdue" : "OK"));
        }

        System.out.println("Total fine collected: Rs " + BookIssue.totalFineCollected(issues));
    }
}

class BookIssue {
    String title;
    String borrowerName;
    int daysOverdue;

    public BookIssue(String title, String borrowerName, int daysOverdue) {
        this.title = title;
        this.borrowerName = borrowerName;
        this.daysOverdue = daysOverdue;
    }

    double fineAmount() {
        return daysOverdue > 0 ? daysOverdue * 5 : 0;
    }

    boolean isSeverelyOverdue() {
        return daysOverdue > 14;
    }

    // fineAmount is not static because it depends on one specific book's
    // own daysOverdue field.
    // totalFineCollected is static because it operates over a whole
    // collection of BookIssue objects, not on the state of any single
    // instance — it belongs to the class as a whole.
    static double totalFineCollected(BookIssue[] issues) {
        double total = 0;
        for (BookIssue issue : issues) total += issue.fineAmount();
        return total;
    }
}
