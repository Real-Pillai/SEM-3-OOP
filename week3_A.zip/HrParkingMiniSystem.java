public class HrParkingMiniSystem {

    public static void main(String[] args) {
        CompanyEmployeeRecord divya = new CompanyEmployeeRecord("Divya", "E1", new ManagerEmployee("E1", "Divya", 70000, 8000));
        CompanyEmployeeRecord karan = new CompanyEmployeeRecord("Karan", "E2", new Employee("E2", "Karan", 40000));
        CompanyEmployeeRecord meera = new CompanyEmployeeRecord("Meera", "E3", new InternEmployee("E3", "Meera", 12000, 10000));

        divya.slot = new ParkingSlot("A1", 4, 3);
        karan.slot = new ParkingSlot("A2", 5, 4);
        // meera intentionally left with no parking

        System.out.println(divya.fullProfile());
        System.out.println(karan.fullProfile());
        System.out.println(meera.fullProfile());

        System.out.println("Total records: " + CompanyEmployeeRecord.totalRecords);
    }
}

class Employee {
    private String empId;
    private String empName;
    private double salary;

    public Employee(String empId, String empName, double salary) {
        this.empId = empId;
        this.empName = empName;
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }
}

class ManagerEmployee extends Employee {
    private double teamBonus;

    public ManagerEmployee(String empId, String empName, double salary, double teamBonus) {
        super(empId, empName, salary);
        this.teamBonus = teamBonus;
    }

    double effectiveSalary() {
        return getSalary() + teamBonus;
    }
}

class InternEmployee extends Employee {
    private double stipendCap;

    public InternEmployee(String empId, String empName, double salary, double stipendCap) {
        super(empId, empName, salary);
        this.stipendCap = stipendCap;
    }

    double effectiveSalary() {
        return Math.min(getSalary(), stipendCap);
    }
}

class ParkingSlot {
    String slotNo;
    int capacity;
    int occupiedCount;

    public ParkingSlot(String slotNo, int capacity, int occupiedCount) {
        this.slotNo = slotNo;
        this.capacity = capacity;
        this.occupiedCount = occupiedCount;
    }

    void allot(String vehicleNo) {
        if (occupiedCount < capacity) occupiedCount++;
    }
}

class CompanyEmployeeRecord {
    String name;
    String empId;
    Employee employee;
    ParkingSlot slot;

    static int totalRecords = 0;

    public CompanyEmployeeRecord(String name, String empId, Employee employee) {
        this.name = name;
        this.empId = empId;
        this.employee = employee;
        totalRecords++;
    }

    String fullProfile() {
        double pay;
        if (employee instanceof ManagerEmployee) {
            pay = ((ManagerEmployee) employee).effectiveSalary();
        } else if (employee instanceof InternEmployee) {
            pay = ((InternEmployee) employee).effectiveSalary();
        } else {
            pay = employee.getSalary();
        }
        String slotStr = (slot == null) ? "no parking assigned" : slot.slotNo;
        return name + " | Pay: Rs " + pay + " | Slot: " + slotStr;
    }
}
