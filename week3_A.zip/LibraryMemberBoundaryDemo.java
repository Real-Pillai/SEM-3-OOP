public class LibraryMemberBoundaryDemo {

    public static void main(String[] args) {
        BrokenLibraryMember m1 = new BrokenLibraryMember("Aditi", "LM-1", 2);
        BrokenLibraryMember m2 = new BrokenLibraryMember("Rohan", "LM-2", 1);
        System.out.println("Broken version:");
        System.out.println(m1.name);
        System.out.println(m2.name);
        System.out.println("(Aditi's data was overwritten — both members now show \"" + m2.name + "\")");

        System.out.println();

        System.out.println("Fixed version:");
        FixedLibraryMember f1 = new FixedLibraryMember("Aditi", 2);
        FixedLibraryMember f2 = new FixedLibraryMember("Rohan", 1);
        f1.printMemberCard();
        f2.printMemberCard();
        FixedLibraryMember.printTotalMembers();
    }
}

// BROKEN: every field is static, so all instances share the SAME fields.
// - name: static means there is only one "name" slot shared by every
//   member object; creating a second member overwrites the first one's name.
// - memberId: same problem — every member ends up sharing one memberId.
// - booksIssued: same problem — every member ends up sharing one count.
// None of these fields represent something shared across the whole class;
// they represent per-member data, so they must be instance fields.
class BrokenLibraryMember {
    static String name;
    static String memberId;
    static int booksIssued;

    public BrokenLibraryMember(String name, String memberId, int booksIssued) {
        BrokenLibraryMember.name = name;
        BrokenLibraryMember.memberId = memberId;
        BrokenLibraryMember.booksIssued = booksIssued;
    }
}

class FixedLibraryMember {
    String name;
    String memberId;
    int booksIssued;

    static String libraryName = "SRM Central Library";
    static int memberCount = 0;

    public FixedLibraryMember(String name, int booksIssued) {
        memberCount++;
        this.name = name;
        this.memberId = "LM-" + (1000 + memberCount);
        this.booksIssued = booksIssued;
    }

    void printMemberCard() {
        System.out.println(name + " | " + memberId);
    }

    static void printTotalMembers() {
        System.out.println("Total members: " + memberCount);
    }
}
