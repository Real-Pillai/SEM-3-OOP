import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HotelBookingSystem {

    public static void main(String[] args) {
        BookingManager manager = new BookingManager();

        Room deluxe101 = new DeluxeRoom("Deluxe Room 101");
        Room standard205 = new StandardRoom("Standard Room 205");
        manager.addRoom(deluxe101);
        manager.addRoom(standard205);

        Customer alice = new Customer("Alice");

        Reservation r1 = manager.bookRoom(deluxe101, LocalDate.of(2024, 12, 1), LocalDate.of(2024, 12, 5), alice);
        if (r1 != null) {
            System.out.println(deluxe101.getName() + " booked from 2024-12-01 to 2024-12-05. Total price: $" + String.format("%.2f", r1.getTotalPrice()));
        }

        Reservation r2 = manager.bookRoom(standard205, LocalDate.of(2024, 12, 3), LocalDate.of(2024, 12, 7), alice);
        if (r2 != null) {
            System.out.println(standard205.getName() + " booked from 2024-12-03 to 2024-12-07. Total price: $" + String.format("%.2f", r2.getTotalPrice()));
        }

        Reservation r3 = manager.bookRoom(deluxe101, LocalDate.of(2024, 12, 3), LocalDate.of(2024, 12, 7), alice);
        if (r3 == null) {
            System.out.println("Booking failed: " + deluxe101.getName() + " is not available for 2024-12-03 to 2024-12-07.");
        }

        boolean cancelled = manager.cancelReservation(r1, LocalDate.of(2024, 11, 20));
        if (cancelled) {
            System.out.println("Reservation for " + deluxe101.getName() + " cancelled successfully.");
        }
    }
}

enum ReservationStatus {
    ACTIVE, CANCELLED
}

abstract class Room {
    protected String name;
    private List<Reservation> reservations = new ArrayList<>();

    public Room(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }

    abstract double getDailyRate();

    boolean isAvailable(LocalDate checkIn, LocalDate checkOut) {
        for (Reservation r : reservations) {
            if (r.getStatus() == ReservationStatus.ACTIVE && datesOverlap(checkIn, checkOut, r.getCheckIn(), r.getCheckOut())) {
                return false;
            }
        }
        return true;
    }

    private boolean datesOverlap(LocalDate start1, LocalDate end1, LocalDate start2, LocalDate end2) {
        return start1.isBefore(end2) && start2.isBefore(end1);
    }

    void addReservation(Reservation reservation) {
        reservations.add(reservation);
    }
}

class StandardRoom extends Room {
    private static final double DAILY_RATE = 150.0;

    public StandardRoom(String name) {
        super(name);
    }

    @Override
    double getDailyRate() {
        return DAILY_RATE;
    }
}

class DeluxeRoom extends Room {
    private static final double DAILY_RATE = 200.0;

    public DeluxeRoom(String name) {
        super(name);
    }

    @Override
    double getDailyRate() {
        return DAILY_RATE;
    }
}

class SuiteRoom extends Room {
    private static final double DAILY_RATE = 350.0;

    public SuiteRoom(String name) {
        super(name);
    }

    @Override
    double getDailyRate() {
        return DAILY_RATE;
    }
}

class Customer {
    private String name;

    public Customer(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }
}

class Reservation {
    private Room room;
    private Customer customer;
    private LocalDate checkIn;
    private LocalDate checkOut;
    private double totalPrice;
    private ReservationStatus status = ReservationStatus.ACTIVE;
    private static final int CANCELLATION_DEADLINE_DAYS = 2;

    public Reservation(Room room, Customer customer, LocalDate checkIn, LocalDate checkOut) {
        this.room = room;
        this.customer = customer;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        long nights = java.time.temporal.ChronoUnit.DAYS.between(checkIn, checkOut);
        this.totalPrice = nights * room.getDailyRate();
    }

    LocalDate getCheckIn() {
        return checkIn;
    }

    LocalDate getCheckOut() {
        return checkOut;
    }

    double getTotalPrice() {
        return totalPrice;
    }

    ReservationStatus getStatus() {
        return status;
    }

    boolean cancel(LocalDate requestDate) {
        long daysUntilCheckIn = java.time.temporal.ChronoUnit.DAYS.between(requestDate, checkIn);
        if (daysUntilCheckIn < CANCELLATION_DEADLINE_DAYS) {
            return false;
        }
        status = ReservationStatus.CANCELLED;
        return true;
    }
}

class BookingManager {
    private Map<String, Room> rooms = new HashMap<>();

    void addRoom(Room room) {
        rooms.put(room.getName(), room);
    }

    Reservation bookRoom(Room room, LocalDate checkIn, LocalDate checkOut, Customer customer) {
        if (!room.isAvailable(checkIn, checkOut)) {
            return null;
        }
        Reservation reservation = new Reservation(room, customer, checkIn, checkOut);
        room.addReservation(reservation);
        return reservation;
    }

    boolean cancelReservation(Reservation reservation, LocalDate requestDate) {
        return reservation.cancel(requestDate);
    }
}
