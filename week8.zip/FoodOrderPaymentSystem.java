import java.util.ArrayList;
import java.util.List;

public class FoodOrderPaymentSystem {

    public static void main(String[] args) {
        Customer customer = new Customer("Alice");

        Order order1 = customer.createOrder();
        System.out.println("Order created.");
        order1.addItem(new FoodItem("Pizza"), 2);
        order1.addItem(new FoodItem("Soda"), 1);
        System.out.println("Added Pizza (Qty 2), Soda (Qty 1).");

        Order emptyOrder = customer.createOrder();
        try {
            emptyOrder.place(new CreditCardPayment(true));
        } catch (IllegalStateException e) {
            System.out.println("Cannot place order: " + e.getMessage());
        }

        order1.place(new CreditCardPayment(true));

        Order order2 = customer.createOrder();
        order2.addItem(new FoodItem("Burger"), 1);
        order2.place(new DigitalWalletPayment(false));
    }
}

class FoodItem {
    private String name;

    public FoodItem(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }
}

// Composition over inheritance: an Order is composed of LineItems.
class LineItem {
    private FoodItem item;
    private int quantity;

    public LineItem(FoodItem item, int quantity) {
        this.item = item;
        this.quantity = quantity;
    }

    FoodItem getItem() {
        return item;
    }

    int getQuantity() {
        return quantity;
    }
}

// Dependency on abstraction: Order depends on IPaymentMethod, not a
// concrete payment class, so new payment types plug in freely.
interface IPaymentMethod {
    boolean pay(double amount);
    String getMethodName();
}

class CreditCardPayment implements IPaymentMethod {
    private boolean simulateSuccess;

    public CreditCardPayment(boolean simulateSuccess) {
        this.simulateSuccess = simulateSuccess;
    }

    @Override
    public boolean pay(double amount) {
        return simulateSuccess;
    }

    @Override
    public String getMethodName() {
        return "Credit Card";
    }
}

class DigitalWalletPayment implements IPaymentMethod {
    private boolean simulateSuccess;

    public DigitalWalletPayment(boolean simulateSuccess) {
        this.simulateSuccess = simulateSuccess;
    }

    @Override
    public boolean pay(double amount) {
        return simulateSuccess;
    }

    @Override
    public String getMethodName() {
        return "Digital Wallet";
    }
}

class CashOnDeliveryPayment implements IPaymentMethod {
    @Override
    public boolean pay(double amount) {
        return true;
    }

    @Override
    public String getMethodName() {
        return "Cash on Delivery";
    }
}

enum OrderStatus {
    CREATED, PLACED, PAID, PENDING_PAYMENT
}

class Order {
    private static int orderCounter = 122;
    private int orderId;
    private List<LineItem> items = new ArrayList<>();
    private OrderStatus status = OrderStatus.CREATED;
    private Customer customer;

    public Order(Customer customer) {
        this.customer = customer;
        orderCounter++;
        this.orderId = orderCounter;
    }

    void addItem(FoodItem item, int quantity) {
        items.add(new LineItem(item, quantity));
    }

    void place(IPaymentMethod paymentMethod) {
        if (items.isEmpty()) {
            throw new IllegalStateException("Order must contain at least one item.");
        }
        status = OrderStatus.PLACED;
        System.out.println("Order placed successfully.");

        boolean success = paymentMethod.pay(0.0);
        if (success) {
            status = OrderStatus.PAID;
            System.out.println("Payment via " + paymentMethod.getMethodName() + " successful. Order status: " + status);
            notifyCustomer("Order #" + orderId + " placed and paid.");
        } else {
            status = OrderStatus.PENDING_PAYMENT;
            System.out.println("Payment via " + paymentMethod.getMethodName() + " failed. Order status: " + status);
            notifyCustomer("Order #" + orderId + " placed, awaiting payment.");
        }
    }

    private void notifyCustomer(String message) {
        System.out.println("Notification: " + message);
    }
}

class Customer {
    private String name;
    private List<Order> orders = new ArrayList<>();

    public Customer(String name) {
        this.name = name;
    }

    Order createOrder() {
        Order order = new Order(this);
        orders.add(order);
        return order;
    }
}
