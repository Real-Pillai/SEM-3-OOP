import java.util.ArrayList;
import java.util.List;

public class EmployeeLeaveManagement {

    public static void main(String[] args) {
        LeaveManager manager = new LeaveManager();

        Employee john = new FullTimeEmployee("John Doe");
        LeaveRequest r1 = john.submitLeaveRequest("2024-10-10", "2024-10-12");
        System.out.println("Leave request submitted by " + john.getName() + " for " + r1.getStartDate() + " to " + r1.getEndDate() + ". Status: " + r1.getStatus());

        manager.approve(r1);
        System.out.println("Leave request for " + john.getName() + " approved. Status: " + r1.getStatus());

        Employee jane = new PartTimeEmployee("Jane Smith");
        LeaveRequest r2 = jane.submitLeaveRequest("2024-11-01", "2024-11-05");
        System.out.println("Leave request submitted by " + jane.getName() + " for " + r2.getStartDate() + " to " + r2.getEndDate() + ". Status: " + r2.getStatus());

        try {
            r1.setStatus(LeaveStatus.PENDING);
        } catch (IllegalStateException e) {
            System.out.println("Cannot change status: " + e.getMessage());
        }
    }
}

enum LeaveStatus {
    PENDING, APPROVED, REJECTED
}

// Abstract base allows different employee types (Full-time, Part-time,
// Contract) to adopt different leave policies without altering the
// core submission/review workflow.
abstract class Employee {
    protected String name;
    protected List<LeaveRequest> leaveRequests = new ArrayList<>();

    public Employee(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }

    LeaveRequest submitLeaveRequest(String startDate, String endDate) {
        LeaveRequest request = new LeaveRequest(this, startDate, endDate);
        leaveRequests.add(request);
        return request;
    }
}

class FullTimeEmployee extends Employee {
    public FullTimeEmployee(String name) {
        super(name);
    }
}

class PartTimeEmployee extends Employee {
    public PartTimeEmployee(String name) {
        super(name);
    }
}

class ContractEmployee extends Employee {
    public ContractEmployee(String name) {
        super(name);
    }
}

class LeaveRequest {
    private Employee employee;
    private String startDate;
    private String endDate;
    private LeaveStatus status = LeaveStatus.PENDING;

    public LeaveRequest(Employee employee, String startDate, String endDate) {
        this.employee = employee;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    String getStartDate() {
        return startDate;
    }

    String getEndDate() {
        return endDate;
    }

    LeaveStatus getStatus() {
        return status;
    }

    // Enforces: once Approved/Rejected, a request can never revert to Pending.
    void setStatus(LeaveStatus newStatus) {
        if (status != LeaveStatus.PENDING && newStatus == LeaveStatus.PENDING) {
            throw new IllegalStateException(status.name().charAt(0) + status.name().substring(1).toLowerCase() + " request cannot revert to Pending.");
        }
        status = newStatus;
    }
}

class LeaveManager {
    void approve(LeaveRequest request) {
        request.setStatus(LeaveStatus.APPROVED);
    }

    void reject(LeaveRequest request) {
        request.setStatus(LeaveStatus.REJECTED);
    }
}
