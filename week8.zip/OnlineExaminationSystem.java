import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OnlineExaminationSystem {

    public static void main(String[] args) {
        Question q1 = new MultipleChoiceQuestion("Q1", "A");
        Question q2 = new MultipleChoiceQuestion("Q2", "B");

        Examination examination = new Examination("Math Quiz");
        examination.addQuestion(q1);
        examination.addQuestion(q2);

        Student student = new Student("Alice");

        Attempt attempt = student.startExamination(examination);
        System.out.println("Examination '" + examination.getName() + "' started by Student.");

        attempt.answer(q1, "A");
        System.out.println("Question 1 answered with 'A'.");

        attempt.answer(q2, "C");
        System.out.println("Question 2 answered with 'C'.");

        attempt.submit();
        System.out.println("Examination '" + examination.getName() + "' submitted successfully.");

        int score = attempt.evaluate();
        System.out.println("Result for '" + examination.getName() + "' attempt: " + score + "/" + examination.getQuestions().size() + " correct");
    }
}

// Abstract Question supports future question types (MCQ, True/False, ...)
// without altering the Examination/Attempt workflow.
abstract class Question {
    protected String questionId;
    protected String correctAnswer;

    public Question(String questionId, String correctAnswer) {
        this.questionId = questionId;
        this.correctAnswer = correctAnswer;
    }

    String getQuestionId() {
        return questionId;
    }

    // Polymorphic evaluation -- each question type decides how to check itself.
    abstract boolean isCorrect(String submittedAnswer);
}

class MultipleChoiceQuestion extends Question {
    public MultipleChoiceQuestion(String questionId, String correctAnswer) {
        super(questionId, correctAnswer);
    }

    @Override
    boolean isCorrect(String submittedAnswer) {
        return correctAnswer.equalsIgnoreCase(submittedAnswer);
    }
}

class TrueFalseQuestion extends Question {
    public TrueFalseQuestion(String questionId, String correctAnswer) {
        super(questionId, correctAnswer);
    }

    @Override
    boolean isCorrect(String submittedAnswer) {
        return correctAnswer.equalsIgnoreCase(submittedAnswer);
    }
}

class Examination {
    private String name;
    private List<Question> questions = new ArrayList<>();

    public Examination(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }

    void addQuestion(Question q) {
        questions.add(q);
    }

    List<Question> getQuestions() {
        return questions;
    }
}

enum AttemptStatus {
    IN_PROGRESS, SUBMITTED
}

class Attempt {
    private Examination examination;
    private Student student;
    private Map<String, String> answers = new HashMap<>();
    private AttemptStatus status = AttemptStatus.IN_PROGRESS;

    public Attempt(Student student, Examination examination) {
        this.student = student;
        this.examination = examination;
    }

    void answer(Question question, String answer) {
        if (status == AttemptStatus.SUBMITTED) {
            throw new IllegalStateException("Cannot change answers after submission");
        }
        answers.put(question.getQuestionId(), answer);
    }

    void submit() {
        if (status == AttemptStatus.SUBMITTED) {
            throw new IllegalStateException("Attempt already submitted");
        }
        status = AttemptStatus.SUBMITTED;
    }

    int evaluate() {
        if (status != AttemptStatus.SUBMITTED) {
            throw new IllegalStateException("Cannot evaluate before submission");
        }
        int correctCount = 0;
        for (Question q : examination.getQuestions()) {
            String submitted = answers.get(q.getQuestionId());
            if (submitted != null && q.isCorrect(submitted)) {
                correctCount++;
            }
        }
        return correctCount;
    }
}

class Student {
    private String name;
    private Map<String, Attempt> attempts = new HashMap<>(); // one attempt per examination

    public Student(String name) {
        this.name = name;
    }

    Attempt startExamination(Examination examination) {
        if (attempts.containsKey(examination.getName())) {
            throw new IllegalStateException("Student already has an attempt for this examination");
        }
        Attempt attempt = new Attempt(this, examination);
        attempts.put(examination.getName(), attempt);
        return attempt;
    }
}

/*
Object interactions:
1. Student.startExamination() creates a new Attempt tied to that Student and Examination,
   enforcing the "one submitted attempt per examination" rule at the Student level.
2. The Attempt records answers in a map keyed by Question ID while IN_PROGRESS.
3. On submit(), the Attempt transitions to SUBMITTED, after which answer() throws --
   enforcing the "cannot change answers after submission" rule as a state guard.
4. evaluate() iterates the Examination's Questions and calls each Question's own
   isCorrect() polymorphically, so new Question subclasses (True/False, etc.) plug in
   without touching Attempt or Examination at all.
*/
