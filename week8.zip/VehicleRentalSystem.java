import java.util.HashMap;
import java.util.Map;

public class VehicleRentalSystem {

    public static void main(String[] args) {
        RentalService service = new RentalService();

        Vehicle luxuryCarA = new LuxuryCar("Luxury Car A");
        Vehicle standardCarB = new StandardCar("Standard Car B");
        service.addVehicle(luxuryCarA);
        service.addVehicle(standardCarB);

        Rental rental1 = service.rentVehicle(luxuryCarA, 3);
        System.out.println(luxuryCarA.getName() + " rented for 3 days. Total charge: $" + String.format("%.2f", rental1.getTotalCharge()));

        Rental rental2 = service.rentVehicle(standardCarB, 5);
        System.out.println(standardCarB.getName() + " rented for 5 days. Total charge: $" + String.format("%.2f", rental2.getTotalCharge()));

        service.returnVehicle(luxuryCarA);
        System.out.println(luxuryCarA.getName() + " returned. Now available.");
    }
}

abstract class Vehicle {
    protected String name;
    protected boolean available = true;

    public Vehicle(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }

    boolean isAvailable() {
        return available;
    }

    void setAvailable(boolean available) {
        this.available = available;
    }

    // Each category defines its own pricing rule.
    abstract double calculateCharge(int days);
}

class StandardCar extends Vehicle {
    private static final double DAILY_RATE = 50.0;

    public StandardCar(String name) {
        super(name);
    }

    @Override
    double calculateCharge(int days) {
        return days * DAILY_RATE;
    }
}

class LuxuryCar extends Vehicle {
    private static final double DAILY_RATE = 100.0;

    public LuxuryCar(String name) {
        super(name);
    }

    @Override
    double calculateCharge(int days) {
        return days * DAILY_RATE;
    }
}

class SuvCar extends Vehicle {
    private static final double DAILY_RATE = 75.0;

    public SuvCar(String name) {
        super(name);
    }

    @Override
    double calculateCharge(int days) {
        return days * DAILY_RATE;
    }
}

class Rental {
    private Vehicle vehicle;
    private int days;
    private double totalCharge;
    private boolean active = true;

    public Rental(Vehicle vehicle, int days) {
        this.vehicle = vehicle;
        this.days = days;
        this.totalCharge = vehicle.calculateCharge(days);
    }

    double getTotalCharge() {
        return totalCharge;
    }

    Vehicle getVehicle() {
        return vehicle;
    }

    boolean isActive() {
        return active;
    }

    void close() {
        active = false;
    }
}

class RentalService {
    private Map<String, Vehicle> vehicles = new HashMap<>();
    private Map<String, Rental> activeRentals = new HashMap<>();

    void addVehicle(Vehicle vehicle) {
        vehicles.put(vehicle.getName(), vehicle);
    }

    Rental rentVehicle(Vehicle vehicle, int days) {
        if (!vehicle.isAvailable()) {
            throw new IllegalStateException(vehicle.getName() + " is not available for rent");
        }
        Rental rental = new Rental(vehicle, days);
        vehicle.setAvailable(false);
        activeRentals.put(vehicle.getName(), rental);
        return rental;
    }

    void returnVehicle(Vehicle vehicle) {
        Rental rental = activeRentals.remove(vehicle.getName());
        if (rental != null) {
            rental.close();
        }
        vehicle.setAvailable(true);
    }
}
