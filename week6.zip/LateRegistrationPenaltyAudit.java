import java.util.Arrays;

public class LateRegistrationPenaltyAudit {

    public static void main(String[] args) {
        WorkshopTicket w = new WorkshopTicket(1200);
        w.pay(1200);
        w.applyLateFee(100);
        System.out.println(w.getBalanceDue());

        double[] history = w.getLateFeeHistory();
        history[0] = 999;
        System.out.println(Arrays.toString(w.getLateFeeHistory()));
    }
}

class EventTicket {
    protected double basePrice;
    private double amountPaid = 0;
    private double[] lateFeeHistory = new double[10];
    private int lateFeeCount = 0;

    public EventTicket(double basePrice) {
        this.basePrice = basePrice;
    }

    void pay(double amount) {
        amountPaid += amount;
    }

    double getBalanceDue() {
        return basePrice - amountPaid;
    }

    protected void applyLateFee(double amount) {
        basePrice += amount;
        lateFeeHistory[lateFeeCount] = amount;
        lateFeeCount++;
    }

    double[] getLateFeeHistory() {
        return Arrays.copyOf(lateFeeHistory, lateFeeCount);
    }
}

class WorkshopTicket extends EventTicket {
    public WorkshopTicket(double basePrice) {
        super(basePrice);
    }

    @Override
    protected void applyLateFee(double amount) {
        super.applyLateFee(amount * 2);
    }
}
