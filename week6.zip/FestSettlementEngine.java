public class FestSettlementEngine {

    public static void main(String[] args) {
        EventTicket t1 = new EventTicket(500);
        System.out.println("TCK-" + t1.getTicketId());
        System.out.println(EventTicket.getTicketsIssued());

        System.out.println(EventTicket.isValidPromoCode("F123A"));
        System.out.println(EventTicket.isValidPromoCode("F12A"));
        System.out.println(EventTicket.isValidPromoCode("X123A"));

        t1.pay(200);
        t1.pay(200, "UPI");
        System.out.println(t1.getBalanceDue());

        System.out.println(processNightlySettlement(new EventTicket[]{
                new GroupTicket(2000, 5),
                null,
                new EventTicket(500)
        }));
    }

    static String processNightlySettlement(EventTicket[] tickets) {
        int processed = 0, nullSkipped = 0, group = 0, individual = 0;
        for (EventTicket t : tickets) {
            if (t == null) {
                nullSkipped++;
                continue;
            }
            processed++;
            if (t instanceof GroupTicket) {
                group++;
            } else {
                individual++;
            }
        }
        return processed + " processed | " + nullSkipped + " null skipped | " + group + " group | " + individual + " individual";
    }
}

class EventTicket {
    private final int ticketId;
    private double basePrice;
    private double amountPaid = 0;

    private static int ticketsIssued = 0;

    public EventTicket(double basePrice) {
        ticketsIssued++;
        this.ticketId = 1000 + ticketsIssued;
        this.basePrice = basePrice;
    }

    int getTicketId() {
        return ticketId;
    }

    static int getTicketsIssued() {
        return ticketsIssued;
    }

    void pay(double amount) {
        amountPaid += amount;
    }

    void pay(double amount, String mode) {
        System.out.println("Paying via " + mode);
        pay(amount);
    }

    double getBalanceDue() {
        return basePrice - amountPaid;
    }

    static boolean isValidPromoCode(String code) {
        if (code == null || code.length() != 5) return false;
        if (code.charAt(0) != 'F') return false;
        if (!Character.isDigit(code.charAt(1))) return false;
        if (!Character.isDigit(code.charAt(2))) return false;
        if (!Character.isDigit(code.charAt(3))) return false;
        if (!Character.isUpperCase(code.charAt(4))) return false;
        return true;
    }
}

class GroupTicket extends EventTicket {
    private int groupSize;

    public GroupTicket(double basePrice, int groupSize) {
        super(basePrice);
        this.groupSize = groupSize;
    }
}
