import java.util.ArrayList;
import java.util.List;

public class CampusCanteenSmartCard {

    public static void main(String[] args) {
        SmartCard card = new SmartCard("C-2045", new HostellerPlan());

        TopUpResult t1 = card.topUp(500);
        if (t1.success) {
            System.out.println("C-2045 topped up with ₹" + String.format("%.2f", 500.0) + ". Balance: ₹" + String.format("%.2f", card.getBalance()));
        }

        Purchase p1 = card.purchase("Veg Thali", 120);
        if (p1 != null) {
            System.out.println("Veg Thali purchased for ₹" + String.format("%.2f", p1.getChargedAmount()) + ". Balance: ₹" + String.format("%.2f", card.getBalance()));
        }

        Purchase p2 = card.purchase("Cold Coffee", 60);
        if (p2 != null) {
            System.out.println("Cold Coffee purchased for ₹" + String.format("%.2f", p2.getChargedAmount()) + ". Balance: ₹" + String.format("%.2f", card.getBalance()));
        }

        PurchaseResult p3 = card.attemptPurchase("Combo", 400);
        if (!p3.success) {
            System.out.println("Purchase failed: Insufficient balance (required ₹" + String.format("%.2f", p3.requiredAmount) + ", available ₹" + String.format("%.2f", p3.availableBalance) + ").");
        }

        RefundResult r1 = card.refund(p1);
        if (r1.success) {
            System.out.println("Refund of ₹" + String.format("%.2f", r1.amount) + " for Veg Thali processed. Balance: ₹" + String.format("%.2f", card.getBalance()));
        }

        RefundResult r2 = card.refund(p1);
        if (!r2.success) {
            System.out.println("Refund rejected: Veg Thali has already been refunded.");
        }

        System.out.println("Mini-statement for C-2045: " + card.getMiniStatement() + " = ₹" + String.format("%.2f", card.getBalance()));
    }
}

// Pricing plan is pluggable: new plans add a class, never touch
// SmartCard's purchase/refund workflow.
interface PricingPlan {
    double getPrice(double basePrice);
}

class DayScholarPlan implements PricingPlan {
    @Override
    public double getPrice(double basePrice) {
        return basePrice;
    }
}

class HostellerPlan implements PricingPlan {
    @Override
    public double getPrice(double basePrice) {
        return basePrice * 0.90;
    }
}

class StaffPlan implements PricingPlan {
    @Override
    public double getPrice(double basePrice) {
        return basePrice * 0.80;
    }
}

enum TransactionType {
    TOPUP, PURCHASE, REFUND
}

class Transaction {
    TransactionType type;
    double amount; // positive for top-up/refund, negative for purchase
    String label;

    public Transaction(TransactionType type, double amount, String label) {
        this.type = type;
        this.amount = amount;
        this.label = label;
    }
}

class Purchase {
    private String itemName;
    private double chargedAmount;
    private boolean refunded = false;

    public Purchase(String itemName, double chargedAmount) {
        this.itemName = itemName;
        this.chargedAmount = chargedAmount;
    }

    String getItemName() {
        return itemName;
    }

    double getChargedAmount() {
        return chargedAmount;
    }

    boolean isRefunded() {
        return refunded;
    }

    void markRefunded() {
        refunded = true;
    }
}

class TopUpResult {
    boolean success;
    String reason;

    TopUpResult(boolean success, String reason) {
        this.success = success;
        this.reason = reason;
    }
}

class PurchaseResult {
    boolean success;
    double requiredAmount;
    double availableBalance;
    Purchase purchase;
}

class RefundResult {
    boolean success;
    double amount;
    String reason;
}

// SmartCard protects the invariant "balance == sum of all transactions" by
// never exposing a setter for balance -- balance is derived from (or kept
// in lockstep with) the private transaction list, and every public
// operation routes through a single consistent update path.
class SmartCard {
    private static final double MIN_TOPUP = 100.0;
    private static final double MAX_BALANCE = 5000.0;

    private String cardNumber;
    private PricingPlan plan;
    private double balance = 0.0;
    private List<Transaction> transactions = new ArrayList<>();
    private boolean blocked = false;

    public SmartCard(String cardNumber, PricingPlan plan) {
        this.cardNumber = cardNumber;
        this.plan = plan;
    }

    double getBalance() {
        return balance;
    }

    void block() {
        blocked = true;
    }

    void unblock() {
        blocked = false;
    }

    TopUpResult topUp(double amount) {
        if (blocked) {
            return new TopUpResult(false, "Card is blocked.");
        }
        if (amount < MIN_TOPUP) {
            return new TopUpResult(false, "Minimum top-up is ₹" + MIN_TOPUP + ".");
        }
        if (balance + amount > MAX_BALANCE) {
            return new TopUpResult(false, "Maximum balance is ₹" + MAX_BALANCE + ".");
        }
        recordTransaction(TransactionType.TOPUP, amount, "Top-up");
        return new TopUpResult(true, null);
    }

    Purchase purchase(String itemName, double basePrice) {
        PurchaseResult result = attemptPurchase(itemName, basePrice);
        return result.success ? result.purchase : null;
    }

    PurchaseResult attemptPurchase(String itemName, double basePrice) {
        PurchaseResult result = new PurchaseResult();
        if (blocked) {
            result.success = false;
            return result;
        }
        double price = plan.getPrice(basePrice);
        if (price > balance) {
            result.success = false;
            result.requiredAmount = price;
            result.availableBalance = balance;
            return result;
        }
        Purchase purchase = new Purchase(itemName, price);
        recordTransaction(TransactionType.PURCHASE, -price, itemName);
        result.success = true;
        result.purchase = purchase;
        return result;
    }

    RefundResult refund(Purchase purchase) {
        RefundResult result = new RefundResult();
        if (purchase == null) {
            result.success = false;
            return result;
        }
        if (purchase.isRefunded()) {
            result.success = false;
            result.reason = purchase.getItemName() + " has already been refunded.";
            return result;
        }
        double amount = purchase.getChargedAmount();
        recordTransaction(TransactionType.REFUND, amount, purchase.getItemName());
        purchase.markRefunded();
        result.success = true;
        result.amount = amount;
        return result;
    }

    private void recordTransaction(TransactionType type, double amount, String label) {
        transactions.add(new Transaction(type, amount, label));
        balance += amount; // balance always equals sum of recorded transactions
    }

    String getMiniStatement() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < transactions.size(); i++) {
            Transaction t = transactions.get(i);
            String sign = t.amount >= 0 ? "+" : "";
            sb.append(sign).append(String.format("%.2f", t.amount));
            if (i < transactions.size() - 1) sb.append(", ");
        }
        return sb.toString();
    }
}
