import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class SmartLabControlPanel {

    public static void main(String[] args) {
        Device labAc = new Device("Lab AC");
        labAc.addCapability(new PowerCapability());
        labAc.addCapability(new TemperatureCapability());

        Device ceilingLights = new Device("Ceiling Lights");
        ceilingLights.addCapability(new PowerCapability());
        ceilingLights.addCapability(new BrightnessCapability());

        Device projector = new Device("Projector");
        projector.addCapability(new PowerCapability());

        List<Device> devices = List.of(labAc, ceilingLights, projector);

        Scene lectureMode = new Scene("Lecture Mode");
        lectureMode.addStep(new SceneStep("power", "ON"));
        lectureMode.addStep(new SceneStep("brightness", "40"));
        lectureMode.addStep(new SceneStep("temperature", "24"));

        System.out.println("Scene 'Lecture Mode' started.");
        int actionsApplied = lectureMode.run(devices);
        System.out.println("Scene 'Lecture Mode' completed: " + actionsApplied + " actions applied.");

        boolean rejected = !labAc.setValue("temperature", 12);
        if (rejected) {
            System.out.println("Rejected: Lab AC temperature must be between 16°C and 30°C.");
        }

        projector.addCapability(new BrightnessCapability());
        System.out.println("Projector: Brightness capability added.");
        projector.setValue("brightness", 70);
        System.out.println("Projector: brightness set to 70%.");
    }
}

// Capability interface: new capabilities (e.g., Timer) are added purely by
// writing a new class, never by touching Device, Scene, or existing devices.
interface Capability {
    String getType();
    boolean setValue(double value); // returns false if out of range; rejects without changing state
    String describeValue();
}

class PowerCapability implements Capability {
    private boolean on = false;

    @Override
    public String getType() {
        return "power";
    }

    @Override
    public boolean setValue(double value) {
        // 1 = ON, 0 = OFF
        on = value != 0;
        return true;
    }

    @Override
    public String describeValue() {
        return on ? "ON" : "OFF";
    }

    boolean isOn() {
        return on;
    }
}

class BrightnessCapability implements Capability {
    private int brightness = 0;

    @Override
    public String getType() {
        return "brightness";
    }

    @Override
    public boolean setValue(double value) {
        if (value < 0 || value > 100) return false;
        brightness = (int) value;
        return true;
    }

    @Override
    public String describeValue() {
        return brightness + "%";
    }
}

class TemperatureCapability implements Capability {
    private int temperature = 16;

    @Override
    public String getType() {
        return "temperature";
    }

    @Override
    public boolean setValue(double value) {
        if (value < 16 || value > 30) return false;
        temperature = (int) value;
        return true;
    }

    @Override
    public String describeValue() {
        return temperature + "°C";
    }
}

// Device holds a collection of Capability objects (composition) instead of
// a deep subclass hierarchy -- any combination of capabilities is just a
// different set of objects in this map, so the design scales to N
// capabilities and 2^N combinations without a single new class per
// combination.
class Device {
    private String name;
    private Map<String, Capability> capabilities = new LinkedHashMap<>();

    public Device(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }

    void addCapability(Capability capability) {
        capabilities.put(capability.getType(), capability);
    }

    boolean hasCapability(String type) {
        return capabilities.containsKey(type);
    }

    boolean setValue(String type, double value) {
        Capability cap = capabilities.get(type);
        if (cap == null) return false;
        return cap.setValue(value);
    }

    String describe(String type) {
        Capability cap = capabilities.get(type);
        return cap == null ? null : cap.describeValue();
    }
}

class SceneStep {
    private String capabilityType;
    private String rawValue;

    public SceneStep(String capabilityType, String rawValue) {
        this.capabilityType = capabilityType;
        this.rawValue = rawValue;
    }

    String getCapabilityType() {
        return capabilityType;
    }

    double getNumericValue() {
        if (rawValue.equalsIgnoreCase("ON")) return 1;
        if (rawValue.equalsIgnoreCase("OFF")) return 0;
        return Double.parseDouble(rawValue);
    }
}

// A Scene is an ordered list of steps; each step is applied to every
// device that has the targeted capability, and devices without it are
// silently skipped.
class Scene {
    private String name;
    private List<SceneStep> steps = new ArrayList<>();

    public Scene(String name) {
        this.name = name;
    }

    void addStep(SceneStep step) {
        steps.add(step);
    }

    int run(List<Device> devices) {
        int actionsApplied = 0;
        for (SceneStep step : steps) {
            for (Device device : devices) {
                if (!device.hasCapability(step.getCapabilityType())) continue;
                boolean applied = device.setValue(step.getCapabilityType(), step.getNumericValue());
                if (applied) {
                    actionsApplied++;
                    printStepResult(device, step);
                }
            }
        }
        return actionsApplied;
    }

    private void printStepResult(Device device, SceneStep step) {
        String type = step.getCapabilityType();
        if (type.equals("power")) {
            System.out.println(device.getName() + ": " + device.describe(type));
        } else if (type.equals("brightness")) {
            System.out.println(device.getName() + ": brightness set to " + device.describe(type));
        } else if (type.equals("temperature")) {
            System.out.println(device.getName() + ": temperature set to " + device.describe(type));
        }
    }
}
