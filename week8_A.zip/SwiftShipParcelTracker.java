import java.util.ArrayList;
import java.util.List;

public class SwiftShipParcelTracker {

    public static void main(String[] args) {
        Customer customer = new Customer("Customer1");
        ParcelService service = new ParcelService();

        Parcel p101 = service.bookParcel(customer, "P101", new ExpressShipping(), 2.0);
        System.out.println("Parcel P101 booked (Express, 2 kg). Charge: ₹" + String.format("%.2f", p101.getCharge()));
        p101.subscribe(new SmsChannel());
        p101.subscribe(new EmailChannel());
        p101.announceCurrentStatus();

        service.markPickedUp(p101);

        boolean cancelled = service.cancelParcel(p101);
        if (!cancelled) {
            System.out.println("Cancellation failed: P101 can be cancelled only while BOOKED.");
        }

        service.markInTransit(p101);

        boolean delivered = service.markDelivered(p101);
        if (!delivered) {
            System.out.println("Invalid transition: IN_TRANSIT -> DELIVERED is not allowed.");
        }
    }
}

enum ParcelStatus {
    BOOKED, PICKED_UP, IN_TRANSIT, OUT_FOR_DELIVERY, DELIVERED
}

// Abstraction for shipping type: each type calculates its own charge.
interface ShippingType {
    double calculateCharge(double weightKg);
    String getName();
}

class StandardShipping implements ShippingType {
    @Override
    public double calculateCharge(double weightKg) {
        return 40 + 10 * weightKg;
    }

    @Override
    public String getName() {
        return "Standard";
    }
}

class ExpressShipping implements ShippingType {
    @Override
    public double calculateCharge(double weightKg) {
        return 80 + 15 * weightKg;
    }

    @Override
    public String getName() {
        return "Express";
    }
}

// Fragile reuses the Standard rule through composition (has-a StandardShipping),
// not inheritance -- it isn't "a kind of" Standard, it just delegates to it
// and adds a flat handling fee on top.
class FragileShipping implements ShippingType {
    private StandardShipping standardRule = new StandardShipping();
    private static final double HANDLING_FEE = 50.0;

    @Override
    public double calculateCharge(double weightKg) {
        return standardRule.calculateCharge(weightKg) + HANDLING_FEE;
    }

    @Override
    public String getName() {
        return "Fragile";
    }
}

interface NotificationChannel {
    void notify(String parcelId, ParcelStatus status);
}

class SmsChannel implements NotificationChannel {
    @Override
    public void notify(String parcelId, ParcelStatus status) {
        System.out.println("[SMS] " + parcelId + " is now " + status);
    }
}

class EmailChannel implements NotificationChannel {
    @Override
    public void notify(String parcelId, ParcelStatus status) {
        System.out.println("[Email] " + parcelId + " is now " + status);
    }
}

class Customer {
    private String name;

    public Customer(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }
}

// The allowed transitions live inside Parcel itself, so no outside code
// can force an invalid status -- advanceTo() is the only way to change
// status and it enforces the strict linear order.
class Parcel {
    private String id;
    private Customer customer;
    private ShippingType shippingType;
    private double weightKg;
    private ParcelStatus status = ParcelStatus.BOOKED;
    private List<NotificationChannel> channels = new ArrayList<>();
    private static final ParcelStatus[] ORDER = {
            ParcelStatus.BOOKED, ParcelStatus.PICKED_UP, ParcelStatus.IN_TRANSIT,
            ParcelStatus.OUT_FOR_DELIVERY, ParcelStatus.DELIVERED
    };

    public Parcel(String id, Customer customer, ShippingType shippingType, double weightKg) {
        this.id = id;
        this.customer = customer;
        this.shippingType = shippingType;
        this.weightKg = weightKg;
    }

    void announceCurrentStatus() {
        notifyAll(status);
    }

    String getId() {
        return id;
    }

    double getCharge() {
        return shippingType.calculateCharge(weightKg);
    }

    ParcelStatus getStatus() {
        return status;
    }

    void subscribe(NotificationChannel channel) {
        channels.add(channel);
    }

    boolean cancel() {
        if (status != ParcelStatus.BOOKED) {
            return false;
        }
        // cancellation does not require a status-order transition; handled separately
        return true;
    }

    boolean advanceTo(ParcelStatus target) {
        int currentIndex = indexOf(status);
        int targetIndex = indexOf(target);
        if (targetIndex != currentIndex + 1) {
            return false; // skipping or moving backwards is not allowed
        }
        status = target;
        notifyAll(status);
        return true;
    }

    private int indexOf(ParcelStatus s) {
        for (int i = 0; i < ORDER.length; i++) {
            if (ORDER[i] == s) return i;
        }
        return -1;
    }

    private void notifyAll(ParcelStatus status) {
        for (NotificationChannel c : channels) {
            c.notify(id, status);
        }
    }
}

class ParcelService {
    private List<Parcel> parcels = new ArrayList<>();

    Parcel bookParcel(Customer customer, String id, ShippingType shippingType, double weightKg) {
        Parcel parcel = new Parcel(id, customer, shippingType, weightKg);
        parcels.add(parcel);
        return parcel;
    }

    boolean markPickedUp(Parcel parcel) {
        return parcel.advanceTo(ParcelStatus.PICKED_UP);
    }

    boolean markInTransit(Parcel parcel) {
        return parcel.advanceTo(ParcelStatus.IN_TRANSIT);
    }

    boolean markOutForDelivery(Parcel parcel) {
        return parcel.advanceTo(ParcelStatus.OUT_FOR_DELIVERY);
    }

    boolean markDelivered(Parcel parcel) {
        return parcel.advanceTo(ParcelStatus.DELIVERED);
    }

    boolean cancelParcel(Parcel parcel) {
        return parcel.cancel();
    }
}
