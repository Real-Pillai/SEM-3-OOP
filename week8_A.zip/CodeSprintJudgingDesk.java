import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CodeSprintJudgingDesk {

    public static void main(String[] args) {
        Hackathon hackathon = new Hackathon("CodeSprint 2026");

        Student asha = hackathon.registerStudent("Asha");
        Student ravi = hackathon.registerStudent("Ravi");
        Student neha = hackathon.registerStudent("Neha");
        Student kiran = hackathon.registerStudent("Kiran");

        Team byteBusters = hackathon.registerTeam("ByteBusters", new InnovationScoringRule(),
                List.of(asha, ravi, neha));
        if (byteBusters != null) {
            System.out.println("Team ByteBusters registered (3 members, Innovation track).");
        }

        // Demonstrate the team-size rule failing (1 member, needs 2-4)
        Team soloCoder = hackathon.registerTeam("SoloCoder", new OpenScoringRule(), List.of(kiran));
        if (soloCoder == null) {
            System.out.println("Registration failed: A team must have 2 to 4 members.");
        }

        Project smartAttend = hackathon.submitProject(byteBusters, "SmartAttend");
        System.out.println("Project 'SmartAttend' submitted by ByteBusters.");

        Judge judge = new Judge("J1");
        boolean scored = hackathon.scoreProject(judge, smartAttend, 8, 7, 9);
        if (scored) {
            System.out.println("Score recorded for 'SmartAttend'. Final score: " + String.format("%.2f", smartAttend.getFinalScore()));
        }

        hackathon.publishResults();
        System.out.println("Results published.");

        boolean rescored = hackathon.scoreProject(judge, smartAttend, 10, 7, 9);
        if (!rescored) {
            System.out.println("Rescore rejected: Results have already been published.");
        }
    }
}

// Each track computes its final score polymorphically from the same three
// raw ratings, so adding a new track means adding a new ScoringRule class --
// the registration/submission/publishing workflow never changes.
interface ScoringRule {
    double computeFinalScore(int idea, int execution, int presentation);
}

class InnovationScoringRule implements ScoringRule {
    @Override
    public double computeFinalScore(int idea, int execution, int presentation) {
        return idea * 0.50 + execution * 0.30 + presentation * 0.20;
    }
}

class OpenScoringRule implements ScoringRule {
    @Override
    public double computeFinalScore(int idea, int execution, int presentation) {
        return (idea + execution + presentation) / 3.0;
    }
}

class Student {
    private String name;

    public Student(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }
}

enum HackathonState {
    OPEN, JUDGING, PUBLISHED
}

class Score {
    int idea;
    int execution;
    int presentation;

    public Score(int idea, int execution, int presentation) {
        this.idea = idea;
        this.execution = execution;
        this.presentation = presentation;
    }
}

class Project {
    private String name;
    private Team team;
    private Score score;
    private double finalScore;

    public Project(String name, Team team) {
        this.name = name;
        this.team = team;
    }

    String getName() {
        return name;
    }

    void recordScore(Score score, double finalScore) {
        this.score = score;
        this.finalScore = finalScore;
    }

    double getFinalScore() {
        return finalScore;
    }
}

class Team {
    private String name;
    private ScoringRule scoringRule;
    private List<Student> members;
    private Project project; // 0..1

    public Team(String name, ScoringRule scoringRule, List<Student> members) {
        this.name = name;
        this.scoringRule = scoringRule;
        this.members = new ArrayList<>(members);
    }

    String getName() {
        return name;
    }

    boolean hasProject() {
        return project != null;
    }

    Project getProject() {
        return project;
    }

    void setProject(Project project) {
        this.project = project;
    }

    ScoringRule getScoringRule() {
        return scoringRule;
    }
}

class Judge {
    private String id;

    public Judge(String id) {
        this.id = id;
    }
}

// Hackathon coordinates Team (1..*), Student (1..*; each student on at most
// one team per hackathon), and Project (0..1 per team), and owns the
// Open -> Judging -> Published state that locks scoring once results
// are out.
class Hackathon {
    private String name;
    private List<Student> students = new ArrayList<>();
    private List<Team> teams = new ArrayList<>();
    private Set<Student> assignedStudents = new HashSet<>();
    private Map<String, Project> projectsByTeam = new HashMap<>();
    private HackathonState state = HackathonState.OPEN;

    public Hackathon(String name) {
        this.name = name;
    }

    Student registerStudent(String name) {
        Student s = new Student(name);
        students.add(s);
        return s;
    }

    Team registerTeam(String teamName, ScoringRule rule, List<Student> members) {
        if (members.size() < 2 || members.size() > 4) {
            return null; // Registration failed: team-size rule
        }
        for (Student s : members) {
            if (assignedStudents.contains(s)) {
                return null; // one-team-per-student rule
            }
        }
        Team team = new Team(teamName, rule, members);
        teams.add(team);
        assignedStudents.addAll(members);
        return team;
    }

    Project submitProject(Team team, String projectName) {
        if (team == null || team.hasProject()) {
            return null; // a team can submit only one project
        }
        Project project = new Project(projectName, team);
        team.setProject(project);
        projectsByTeam.put(team.getName(), project);
        if (state == HackathonState.OPEN) {
            state = HackathonState.JUDGING;
        }
        return project;
    }

    boolean scoreProject(Judge judge, Project project, int idea, int execution, int presentation) {
        if (state == HackathonState.PUBLISHED) {
            return false; // Rescore rejected: results already published
        }
        Score score = new Score(idea, execution, presentation);
        double finalScore = project.getFinalScore(); // placeholder, overwritten below
        Team team = findTeamForProject(project);
        finalScore = team.getScoringRule().computeFinalScore(idea, execution, presentation);
        project.recordScore(score, finalScore);
        return true;
    }

    private Team findTeamForProject(Project project) {
        for (Team t : teams) {
            if (t.getProject() == project) return t;
        }
        return null;
    }

    void publishResults() {
        state = HackathonState.PUBLISHED;
    }
}
