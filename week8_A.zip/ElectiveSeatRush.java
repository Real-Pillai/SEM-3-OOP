import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ElectiveSeatRush {

    public static void main(String[] args) {
        Elective cloudComputing = new Elective("Cloud Computing", 4, 2);

        Student asha = new Student("Asha", new RegularCreditPolicy(), 20);
        Student ravi = new Student("Ravi", new HonorsCreditPolicy(), 22);
        Student neha = new Student("Neha", new ExchangeCreditPolicy(), 12);
        Student kiran = new Student("Kiran", new RegularCreditPolicy(), 22);

        EnrollmentService service = new EnrollmentService();

        EnrollResult r1 = service.enroll(asha, cloudComputing);
        print(r1, asha, cloudComputing);

        EnrollResult r2 = service.enroll(ravi, cloudComputing);
        print(r2, ravi, cloudComputing);

        EnrollResult r3 = service.enroll(neha, cloudComputing);
        print(r3, neha, cloudComputing);

        EnrollResult r4 = service.enroll(kiran, cloudComputing);
        print(r4, kiran, cloudComputing);

        service.drop(asha, cloudComputing);
    }

    static void print(EnrollResult result, Student student, Elective elective) {
        if (result.status == EnrollStatus.ENROLLED) {
            System.out.println(student.getName() + " enrolled in " + elective.getName() +
                    " (credits: " + student.getCreditsUsed() + "/" + student.getCreditLimit() + ").");
        } else if (result.status == EnrollStatus.FULL_WAITLISTED) {
            System.out.println(elective.getName() + " is full.");
            System.out.println(student.getName() + " added to waitlist (position " + result.waitlistPosition + ").");
        } else if (result.status == EnrollStatus.CREDIT_LIMIT_EXCEEDED) {
            System.out.println("Enrollment failed: " + student.getName() + " would exceed the " +
                    student.getCreditPolicy().getTypeName() + " credit limit (" + result.wouldBeCredits + "/" + student.getCreditLimit() + ").");
        }
    }
}

enum EnrollStatus {
    ENROLLED, FULL_WAITLISTED, CREDIT_LIMIT_EXCEEDED, ALREADY_ENROLLED_OR_WAITING
}

class EnrollResult {
    EnrollStatus status;
    int waitlistPosition;
    int wouldBeCredits;

    EnrollResult(EnrollStatus status) {
        this.status = status;
    }
}

// Pluggable credit policy: new student types add a new CreditPolicy class
// without touching EnrollmentService or Elective.
interface CreditPolicy {
    int getCreditLimit();
    String getTypeName();
}

class RegularCreditPolicy implements CreditPolicy {
    @Override
    public int getCreditLimit() {
        return 24;
    }

    @Override
    public String getTypeName() {
        return "Regular";
    }
}

class HonorsCreditPolicy implements CreditPolicy {
    @Override
    public int getCreditLimit() {
        return 28;
    }

    @Override
    public String getTypeName() {
        return "Honors";
    }
}

class ExchangeCreditPolicy implements CreditPolicy {
    @Override
    public int getCreditLimit() {
        return 20;
    }

    @Override
    public String getTypeName() {
        return "Exchange";
    }
}

class Student {
    private String name;
    private CreditPolicy creditPolicy;
    private int creditsUsed;
    private Set<Elective> enrolledOrWaiting = new HashSet<>();

    public Student(String name, CreditPolicy creditPolicy, int creditsUsed) {
        this.name = name;
        this.creditPolicy = creditPolicy;
        this.creditsUsed = creditsUsed;
    }

    String getName() {
        return name;
    }

    CreditPolicy getCreditPolicy() {
        return creditPolicy;
    }

    int getCreditLimit() {
        return creditPolicy.getCreditLimit();
    }

    int getCreditsUsed() {
        return creditsUsed;
    }

    void addCredits(int credits) {
        creditsUsed += credits;
    }

    void removeCredits(int credits) {
        creditsUsed -= credits;
    }

    boolean isInvolvedWith(Elective elective) {
        return enrolledOrWaiting.contains(elective);
    }

    void markInvolved(Elective elective) {
        enrolledOrWaiting.add(elective);
    }

    void markNotInvolved(Elective elective) {
        enrolledOrWaiting.remove(elective);
    }
}

// Elective protects its own invariant: enrolled.size() <= capacity, always.
// The waitlist is a private queue -- no outside code can reorder or peek
// into it except through Elective's own operations.
class Elective {
    private String name;
    private int credits;
    private int capacity;
    private List<Student> enrolledStudents = new ArrayList<>();
    private Deque<Student> waitlist = new ArrayDeque<>();

    public Elective(String name, int credits, int capacity) {
        this.name = name;
        this.credits = credits;
        this.capacity = capacity;
    }

    String getName() {
        return name;
    }

    int getCredits() {
        return credits;
    }

    boolean hasSeat() {
        return enrolledStudents.size() < capacity;
    }

    void enrollDirectly(Student student) {
        enrolledStudents.add(student);
    }

    int addToWaitlist(Student student) {
        waitlist.addLast(student);
        return waitlist.size();
    }

    Student peekWaitlist() {
        return waitlist.peekFirst();
    }

    void popWaitlist() {
        waitlist.pollFirst();
    }

    void removeFromEnrolled(Student student) {
        enrolledStudents.remove(student);
    }
}

// EnrollmentService is the single entry point for enroll/drop, so
// drop-and-promote always happens as one consistent operation.
class EnrollmentService {

    EnrollResult enroll(Student student, Elective elective) {
        if (student.isInvolvedWith(elective)) {
            return new EnrollResult(EnrollStatus.ALREADY_ENROLLED_OR_WAITING);
        }

        int wouldBeCredits = student.getCreditsUsed() + elective.getCredits();
        if (wouldBeCredits > student.getCreditLimit()) {
            EnrollResult result = new EnrollResult(EnrollStatus.CREDIT_LIMIT_EXCEEDED);
            result.wouldBeCredits = wouldBeCredits;
            return result;
        }

        if (!elective.hasSeat()) {
            student.markInvolved(elective);
            int position = elective.addToWaitlist(student);
            EnrollResult result = new EnrollResult(EnrollStatus.FULL_WAITLISTED);
            result.waitlistPosition = position;
            return result;
        }

        elective.enrollDirectly(student);
        student.markInvolved(elective);
        student.addCredits(elective.getCredits());
        return new EnrollResult(EnrollStatus.ENROLLED);
    }

    void drop(Student student, Elective elective) {
        elective.removeFromEnrolled(student);
        student.removeCredits(elective.getCredits());
        student.markNotInvolved(elective);
        System.out.println(student.getName() + " dropped " + elective.getName() +
                " (credits: " + student.getCreditsUsed() + "/" + student.getCreditLimit() + ").");

        promoteFromWaitlist(elective);
    }

    private void promoteFromWaitlist(Elective elective) {
        Student candidate = elective.peekWaitlist();
        if (candidate == null) return;

        int wouldBeCredits = candidate.getCreditsUsed() + elective.getCredits();
        if (wouldBeCredits > candidate.getCreditLimit()) {
            // Eligible means credit limit re-checked; if it fails, candidate stays waitlisted
            // (per spec, only the first eligible student is promoted -- here we stop,
            // matching the simple sample scenario).
            return;
        }

        elective.popWaitlist();
        elective.enrollDirectly(candidate);
        candidate.addCredits(elective.getCredits());
        System.out.println(candidate.getName() + " promoted from waitlist and enrolled in " +
                elective.getName() + " (credits: " + candidate.getCreditsUsed() + "/" + candidate.getCreditLimit() + ").");
    }
}
