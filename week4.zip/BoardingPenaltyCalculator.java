public final class BoardingPenaltyCalculator {

    private final double minimumPenaltyPercent;

    public BoardingPenaltyCalculator(double minimumPenaltyPercent) {
        this.minimumPenaltyPercent = minimumPenaltyPercent;
    }

    final double calculatePenalty(double ticketFare, int minutesLate) {
        if (ticketFare < 0 || minutesLate < 0) {
            throw new IllegalArgumentException("ticketFare and minutesLate must be non-negative");
        }
        if (minutesLate == 0) {
            return 0.0;
        }

        double tieredFee = 0.0;

        int band1 = Math.min(minutesLate, 5);
        tieredFee += band1 * 0.005 * ticketFare;

        if (minutesLate > 5) {
            int band2 = Math.min(minutesLate, 15) - 5;
            tieredFee += band2 * 0.01 * ticketFare;
        }

        if (minutesLate > 15) {
            int band3 = minutesLate - 15;
            tieredFee += band3 * 0.02 * ticketFare;
        }

        double floorFee = (minimumPenaltyPercent / 100.0) * ticketFare;

        return Math.max(tieredFee, floorFee);
    }

    public static void main(String[] args) {
        BoardingPenaltyCalculator calc = new BoardingPenaltyCalculator(1.0);
        System.out.println("Rs " + calc.calculatePenalty(1000, 0));
        System.out.println("Rs " + calc.calculatePenalty(1000, 1));
        System.out.println("Rs " + calc.calculatePenalty(1000, 16));
    }
}
