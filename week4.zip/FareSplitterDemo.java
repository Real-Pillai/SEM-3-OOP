public class FareSplitterDemo {

    public static void main(String[] args) {
        double[] result1 = new FareSplitter("TRIP001", 100000, 3).fareBreakdown();
        printArray(result1);

        double[] result2 = new FareSplitter("TRIP003").fareBreakdown();
        printArray(result2);
    }

    static void printArray(double[] arr) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < arr.length; i++) {
            sb.append(String.format("%.2f", arr[i]));
            if (i < arr.length - 1) sb.append(", ");
        }
        sb.append("]");
        System.out.println(sb);
    }
}

class FareSplitter {
    private String tripId;
    private double totalFare;
    private int passengerCount;

    public FareSplitter(String tripId, double totalFare, int passengerCount) {
        if (totalFare < 0) {
            throw new IllegalArgumentException("totalFare must not be negative");
        }
        if (passengerCount <= 0) {
            throw new IllegalArgumentException("passengerCount must be positive");
        }
        this.tripId = tripId;
        this.totalFare = totalFare;
        this.passengerCount = passengerCount;
    }

    public FareSplitter(String tripId, double totalFare) {
        this(tripId, totalFare, 1);
    }

    public FareSplitter(String tripId) {
        this(tripId, 0.0, 2);
    }

    double[] fareBreakdown() {
        double[] shares = new double[passengerCount];
        long totalPaise = Math.round(totalFare * 100);
        long basePaise = totalPaise / passengerCount;
        long remainderPaise = totalPaise % passengerCount;

        for (int i = 0; i < passengerCount; i++) {
            shares[i] = basePaise / 100.0;
        }
        // distribute leftover paise to the LAST shares so the total is exact
        for (int i = passengerCount - (int) remainderPaise; i < passengerCount; i++) {
            shares[i] += 0.01;
        }

        return shares;
    }

    boolean isConfirmationOverdue(int confirmed, int expected) {
        return confirmed < expected;
    }
}
