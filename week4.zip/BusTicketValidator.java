import java.util.HashSet;
import java.util.Set;

public class BusTicketValidator {

    public static void main(String[] args) {
        String[][] rawBookings = {
                {"Divya", "Chennai"},
                {"", "Bangalore"},
                {"Ravi123", "Pune"},
                {"Divya", "Chennai"},
                {" ", " "}
        };
        processBatch(rawBookings);
    }

    static void processBatch(String[][] rawBookings) {
        Set<String> seen = new HashSet<>();
        int valid = 0, rejected = 0, duplicates = 0;

        for (String[] raw : rawBookings) {
            try {
                BusTicket ticket = new BusTicket(raw[0], raw[1]);
                String key = raw[0] + "|" + raw[1];
                if (seen.contains(key)) {
                    duplicates++;
                } else {
                    seen.add(key);
                    valid++;
                }
            } catch (IllegalArgumentException e) {
                rejected++;
            }
        }

        System.out.println("Valid: " + valid + " | Rejected: " + rejected + " | Duplicates skipped: " + duplicates);
    }
}

class BusTicket {
    private String passengerName;
    private String destination;
    private boolean checkedIn = false;

    public BusTicket(String passengerName, String destination) {
        if (!isMeaningful(passengerName)) {
            throw new IllegalArgumentException("passengerName must be meaningful");
        }
        if (!isMeaningful(destination)) {
            throw new IllegalArgumentException("destination must be meaningful");
        }
        this.passengerName = passengerName;
        this.destination = destination;
    }

    // A meaningful name/destination is non-null, non-blank after trimming,
    // and contains no digits (e.g. "Ravi123" is rejected).
    private boolean isMeaningful(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        for (char c : value.toCharArray()) {
            if (Character.isDigit(c)) return false;
        }
        return true;
    }

    void markCheckedIn() {
        if (checkedIn) {
            System.out.println("Ticket already checked in!");
        } else {
            checkedIn = true;
            System.out.println("Ticket checked in.");
        }
    }
}
