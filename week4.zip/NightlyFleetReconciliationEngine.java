public class NightlyFleetReconciliationEngine {

    public static void main(String[] args) {
        BusTicketAccount[] accounts = {
                new SleeperBusTicketAccount("BK001", 2000),
                null,
                new BusTicketAccount("BK002", 1200)
        };
        double[] amounts = {1200, 900, 700};
        int[] minutesLateArray = {10, 5, 0};

        processBatch(accounts, amounts, minutesLateArray);
    }

    static void processAccount(BusTicketAccount account, double amount, int minutesLate) {
        account.calculatePenalty(minutesLate);
    }

    static void processBatch(BusTicketAccount[] accounts, double[] amounts, int[] minutesLateArray) {
        int len = Math.min(accounts.length, Math.min(amounts.length, minutesLateArray.length));

        int processed = 0, nullSkipped = 0, sleeper = 0, regular = 0;
        double grandTotal = 0.0;

        for (int i = 0; i < len; i++) {
            BusTicketAccount account = accounts[i];
            if (account == null) {
                nullSkipped++;
                continue;
            }
            double penalty = account.calculatePenalty(minutesLateArray[i]);
            grandTotal += penalty;
            processed++;
            if (account instanceof SleeperBusTicketAccount) {
                sleeper++;
            } else {
                regular++;
            }
        }

        System.out.println(processed + " processed | " + nullSkipped + " null skipped | " +
                sleeper + " sleeper | " + regular + " regular | grand total penalties = " + grandTotal);
    }
}

class BusTicketAccount {
    private String bookingId;
    private double ticketFare;

    private static int totalAccountsCreated;
    static {
        totalAccountsCreated = 0;
    }

    public BusTicketAccount(String bookingId, double ticketFare) {
        this.bookingId = bookingId;
        this.ticketFare = ticketFare;
        totalAccountsCreated++;
    }

    public BusTicketAccount(String bookingId) {
        this(bookingId, 0.0);
    }

    // Simple flat-rate penalty: 1% of ticket fare per minute late.
    final double calculatePenalty(int minutesLate) {
        if (minutesLate <= 0) return 0.0;
        return ticketFare * 0.01 * minutesLate;
    }
}

class SleeperBusTicketAccount extends BusTicketAccount {
    public SleeperBusTicketAccount(String bookingId, double ticketFare) {
        super(bookingId, ticketFare);
    }

    public SleeperBusTicketAccount(String bookingId) {
        super(bookingId);
    }
}
