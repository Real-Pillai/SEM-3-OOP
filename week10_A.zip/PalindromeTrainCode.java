public class PalindromeTrainCode {

    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
        }
    }

    // O(n) time, O(1) extra space -- compared to copying all values into
    // an array (O(n) time but O(n) extra space), this approach reuses the
    // existing list nodes instead: it finds the middle with slow/fast
    // pointers, reverses the second half in place, compares the two
    // halves node-by-node, then reverses the second half again to
    // restore the original list before returning.
    static boolean isPalindrome(Node head) {
        if (head == null || head.next == null) return true;

        // Find the middle using slow/fast pointers.
        Node slow = head, fast = head;
        while (fast.next != null && fast.next.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }

        // Reverse the second half, starting just after slow.
        Node secondHalfStart = reverse(slow.next);

        // Compare first half with reversed second half.
        Node p1 = head;
        Node p2 = secondHalfStart;
        boolean result = true;
        while (p2 != null) {
            if (p1.data != p2.data) {
                result = false;
                break;
            }
            p1 = p1.next;
            p2 = p2.next;
        }

        // Restore the list by reversing the second half back.
        slow.next = reverse(secondHalfStart);

        return result;
    }

    private static Node reverse(Node head) {
        Node prev = null;
        while (head != null) {
            Node nextNode = head.next;
            head.next = prev;
            prev = head;
            head = nextNode;
        }
        return prev;
    }

    static Node buildList(int[] values) {
        Node dummy = new Node(0);
        Node tail = dummy;
        for (int v : values) {
            tail.next = new Node(v);
            tail = tail.next;
        }
        return dummy.next;
    }

    static String toStringList(Node head) {
        StringBuilder sb = new StringBuilder();
        while (head != null) {
            sb.append(head.data);
            if (head.next != null) sb.append(" -> ");
            head = head.next;
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        Node list1 = buildList(new int[]{1, 2, 3, 2, 1});
        System.out.println(isPalindrome(list1));

        Node list2 = buildList(new int[]{1, 2, 3, 2});
        System.out.println(isPalindrome(list2));

        Node list3 = buildList(new int[]{1, 2, 2, 1});
        boolean result3 = isPalindrome(list3);
        System.out.println(result3 + " (list afterwards: " + toStringList(list3) + ")");
    }
}
