public class PolynomialCalculator {

    static class Node {
        int coefficient;
        int exponent;
        Node next;

        Node(int coefficient, int exponent) {
            this.coefficient = coefficient;
            this.exponent = exponent;
        }
    }

    // This is a merge of two sorted (by decreasing exponent) lists:
    // O(m + n) time, each input list is visited exactly once; O(m + n)
    // space in the worst case for the result list (fewer if terms
    // cancel to zero and are dropped).
    static Node addPolynomials(Node p, Node q) {
        Node dummy = new Node(0, 0);
        Node tail = dummy;

        while (p != null && q != null) {
            if (p.exponent > q.exponent) {
                tail.next = new Node(p.coefficient, p.exponent);
                tail = tail.next;
                p = p.next;
            } else if (q.exponent > p.exponent) {
                tail.next = new Node(q.coefficient, q.exponent);
                tail = tail.next;
                q = q.next;
            } else {
                int sum = p.coefficient + q.coefficient;
                if (sum != 0) {
                    tail.next = new Node(sum, p.exponent);
                    tail = tail.next;
                }
                p = p.next;
                q = q.next;
            }
        }

        Node remaining = (p != null) ? p : q;
        while (remaining != null) {
            tail.next = new Node(remaining.coefficient, remaining.exponent);
            tail = tail.next;
            remaining = remaining.next;
        }

        return dummy.next;
    }

    static Node buildPolynomial(int[][] terms) {
        Node dummy = new Node(0, 0);
        Node tail = dummy;
        for (int[] term : terms) {
            tail.next = new Node(term[0], term[1]);
            tail = tail.next;
        }
        return dummy.next;
    }

    static String toStandardForm(Node head) {
        if (head == null) return "0";
        StringBuilder sb = new StringBuilder();
        boolean first = true;

        while (head != null) {
            int coeff = head.coefficient;
            int exp = head.exponent;

            if (!first) {
                sb.append(coeff < 0 ? " - " : " + ");
            } else if (coeff < 0) {
                sb.append("-");
            }

            int absCoeff = Math.abs(coeff);
            if (exp == 0) {
                sb.append(absCoeff);
            } else if (exp == 1) {
                if (absCoeff != 1) sb.append(absCoeff);
                sb.append("x");
            } else {
                if (absCoeff != 1) sb.append(absCoeff);
                sb.append("x^").append(exp);
            }

            first = false;
            head = head.next;
        }

        return sb.toString();
    }

    public static void main(String[] args) {
        Node p1 = buildPolynomial(new int[][]{{5, 3}, {4, 2}, {2, 0}});
        Node q1 = buildPolynomial(new int[][]{{5, 2}, {-3, 1}, {1, 0}});
        Node result1 = addPolynomials(p1, q1);
        System.out.println(toStandardForm(result1));

        Node p2 = buildPolynomial(new int[][]{{3, 2}, {1, 0}});
        Node q2 = buildPolynomial(new int[][]{{-3, 2}, {4, 1}});
        Node result2 = addPolynomials(p2, q2);
        System.out.println(toStandardForm(result2));
    }
}
