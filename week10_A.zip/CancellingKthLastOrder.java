public class CancellingKthLastOrder {

    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
        }
    }

    // Single pass, O(n) time, O(1) extra space. A dummy node placed before
    // head means "removing the head" (sample 2) needs no special case:
    // the dummy always has a valid .next to relink, even when the node
    // being removed is the original head itself.
    static Node removeKthFromEnd(Node head, int k) {
        Node dummy = new Node(0);
        dummy.next = head;

        Node lead = dummy;
        Node trail = dummy;

        // Move lead k + 1 steps ahead of trail.
        for (int i = 0; i < k + 1; i++) {
            lead = lead.next;
        }

        // Move both until lead falls off the end; trail now sits just
        // before the node to remove.
        while (lead != null) {
            lead = lead.next;
            trail = trail.next;
        }

        trail.next = trail.next.next;
        return dummy.next;
    }

    static Node buildList(int[] values) {
        Node dummy = new Node(0);
        Node tail = dummy;
        for (int v : values) {
            tail.next = new Node(v);
            tail = tail.next;
        }
        return dummy.next;
    }

    static String toStringList(Node head) {
        StringBuilder sb = new StringBuilder();
        while (head != null) {
            sb.append(head.data);
            if (head.next != null) sb.append(" -> ");
            head = head.next;
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        Node list1 = buildList(new int[]{10, 20, 30, 40, 50});
        Node result1 = removeKthFromEnd(list1, 2);
        System.out.println(toStringList(result1));

        Node list2 = buildList(new int[]{10, 20, 30, 40, 50});
        Node result2 = removeKthFromEnd(list2, 5);
        System.out.println(toStringList(result2));
    }
}
