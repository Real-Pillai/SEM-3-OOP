public class CampusPortalBrowserHistory {

    static class Node {
        String data;
        Node prev, next;

        Node(String data) {
            this.data = data;
        }
    }

    // visit(): O(1). back(steps)/forward(steps): O(steps), stopping early
    // at the first/last page. Space: O(number of distinct pages visited).
    // A visit() drops all forward history by unlinking current.next; those
    // discarded nodes have no remaining references into the list and
    // become eligible for garbage collection.
    static class BrowserHistory {
        private Node current;

        public BrowserHistory(String homepage) {
            current = new Node(homepage);
        }

        void visit(String url) {
            Node newNode = new Node(url);
            newNode.prev = current;
            current.next = newNode; // discards any old forward chain
            current = newNode;
        }

        String back(int steps) {
            while (steps > 0 && current.prev != null) {
                current = current.prev;
                steps--;
            }
            return current.data;
        }

        String forward(int steps) {
            while (steps > 0 && current.next != null) {
                current = current.next;
                steps--;
            }
            return current.data;
        }
    }

    public static void main(String[] args) {
        BrowserHistory browser = new BrowserHistory("srm.edu");

        browser.visit("a.com");
        browser.visit("b.com");
        browser.visit("c.com");

        System.out.println(browser.back(1));
        System.out.println(browser.back(1));
        System.out.println(browser.forward(1));
        browser.visit("d.com");
        System.out.println(browser.forward(2));
        System.out.println(browser.back(2));
        System.out.println(browser.back(7));
    }
}
