public class MergingTwoTicketCounters {

    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
        }
    }

    // O(m + n) time: each node from both lists is visited and relinked
    // exactly once. O(1) extra space: only a dummy node and a tail
    // pointer are used -- no new nodes are created, existing nodes are
    // simply relinked. Compare to copying both lists into an array and
    // sorting: that costs O((m+n) log(m+n)) time and O(m+n) extra space
    // for the array, strictly worse on both counts since the inputs are
    // already individually sorted.
    static Node mergeSorted(Node a, Node b) {
        Node dummy = new Node(0);
        Node tail = dummy;

        while (a != null && b != null) {
            if (a.data <= b.data) {
                tail.next = a;
                a = a.next;
            } else {
                tail.next = b;
                b = b.next;
            }
            tail = tail.next;
        }

        tail.next = (a != null) ? a : b;

        return dummy.next;
    }

    static Node buildList(int[] values) {
        Node dummy = new Node(0);
        Node tail = dummy;
        for (int v : values) {
            tail.next = new Node(v);
            tail = tail.next;
        }
        return dummy.next;
    }

    static String toStringList(Node head) {
        StringBuilder sb = new StringBuilder();
        while (head != null) {
            sb.append(head.data);
            if (head.next != null) sb.append(" -> ");
            head = head.next;
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        Node a1 = buildList(new int[]{3, 8, 15});
        Node b1 = buildList(new int[]{5, 8, 12, 20});
        System.out.println(toStringList(mergeSorted(a1, b1)));

        Node a2 = null;
        Node b2 = buildList(new int[]{4});
        System.out.println(toStringList(mergeSorted(a2, b2)));
    }
}
