public class LibraryMemberJavaBeanDemo {

    public static void main(String[] args) {
        System.out.println(new LibraryMemberBean("Priya Nair").getMembershipId());
        System.out.println(new LibraryMemberBean("LIB-8841", "Priya Nair").getMembershipId());

        LibraryMemberBean m = new LibraryMemberBean();
        m.setMembershipId("LIB-8841");
        m.setMembershipId("FAKE-0000");
        System.out.println(m.getMembershipId());
    }
}

class LibraryMemberBean {
    private String membershipId;
    private String name;
    private boolean premiumMember;
    private String securityAnswerHash;
    private boolean membershipIdSet = false;

    public LibraryMemberBean() {
        this.name = null;
    }

    public LibraryMemberBean(String name) {
        this();
        this.name = name;
    }

    public LibraryMemberBean(String membershipId, String name) {
        this(name);
        setMembershipId(membershipId);
    }

    public String getMembershipId() {
        return membershipId;
    }

    public void setMembershipId(String id) {
        if (!membershipIdSet) {
            this.membershipId = id;
            this.membershipIdSet = true;
        }
        // silently ignore subsequent calls
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isPremiumMember() {
        return premiumMember;
    }

    public void setPremiumMember(boolean premium) {
        this.premiumMember = premium;
    }

    public void setSecurityAnswer(String answer) {
        // one-way transformation; no getter exists anywhere
        this.securityAnswerHash = String.valueOf(answer.hashCode());
    }
}
