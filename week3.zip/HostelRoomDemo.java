public class HostelRoomDemo {

    public static void main(String[] args) {
        HostelRoom[] rooms1 = {new HostelRoom("C-214", 3, 2), new HostelRoom("C-507", 2, 2)};
        safeAllot(rooms1, "Divya");

        HostelRoom[] rooms2 = {new HostelRoom("C-214", 3, 3), new HostelRoom("C-507", 2, 2)};
        safeAllot(rooms2, "Divya");
    }

    // Arrays in Java hold references to objects, not the objects themselves.
    // Passing the array passes copies of those references, so all methods
    // that receive it still point to the same underlying HostelRoom objects —
    // no copying of room data occurs.
    static HostelRoom findAvailableRoom(HostelRoom[] rooms) {
        for (HostelRoom room : rooms) {
            if (room.occupied < room.beds) return room;
        }
        return null;
    }

    static void safeAllot(HostelRoom[] rooms, String studentName) {
        HostelRoom room = findAvailableRoom(rooms);
        if (room == null) {
            System.out.println("No rooms available for " + studentName);
            return;
        }
        room.allot(studentName);
        System.out.println(studentName + " allotted to room " + room.roomNo);
    }
}

class HostelRoom {
    String roomNo;
    int beds;
    int occupied;

    public HostelRoom(String roomNo, int beds, int occupied) {
        this.roomNo = roomNo;
        this.beds = beds;
        this.occupied = occupied;
    }

    void allot(String name) {
        if (occupied < beds) {
            occupied++;
        }
    }
}
