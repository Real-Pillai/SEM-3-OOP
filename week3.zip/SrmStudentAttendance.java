public class SrmStudentAttendance {

    public static void main(String[] args) {
        SrmStudent[] students = new SrmStudent[]{
                new SrmStudent("Ravi", "RA01", 82),
                new SrmStudent("Anitha", "RA02", 68),
                new SrmStudent("Karthik", "RA03", 91),
                new SrmStudent("Meera", "RA04", 74),
                new SrmStudent("Suresh", "RA05", 60)
        };

        for (SrmStudent s : students) {
            System.out.println(s.name + " - " + s.attendance + "% - " + (s.isEligible() ? "Eligible" : "Detained"));
        }

        System.out.println("Class average: " + SrmStudent.classAverage(students) + "%");
    }
}

class SrmStudent {
    String name;
    String regNo;
    int attendance;

    public SrmStudent(String name, String regNo, int attendance) {
        this.name = name;
        this.regNo = regNo;
        this.attendance = attendance;
    }

    void addAttendanceUpdate(int newAttendance) {
        this.attendance = newAttendance;
    }

    boolean isEligible() {
        return attendance >= 75;
    }

    // classAverage is static because it operates on a whole collection of
    // SrmStudent objects, not on the state of any single instance — it
    // belongs to the class as a whole, not to one student.
    // isEligible is not static because it depends on one specific
    // student's own attendance field.
    static double classAverage(SrmStudent[] students) {
        int sum = 0;
        for (SrmStudent s : students) sum += s.attendance;
        return (double) sum / students.length;
    }
}
