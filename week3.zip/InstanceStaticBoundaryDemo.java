public class InstanceStaticBoundaryDemo {

    public static void main(String[] args) {
        // Broken version demonstration
        BrokenSrmStudent b1 = new BrokenSrmStudent("Ravi", "RA1", 80);
        BrokenSrmStudent b2 = new BrokenSrmStudent("Meera", "RA2", 85);
        System.out.println("Broken version:");
        System.out.println(b1.name);
        System.out.println(b2.name);
        System.out.println("(Ravi's data was overwritten — both students now show \"" + b2.name + "\")");

        System.out.println();

        // Fixed version demonstration
        System.out.println("Fixed version:");
        FixedSrmStudent f1 = new FixedSrmStudent("Ravi", 80);
        FixedSrmStudent f2 = new FixedSrmStudent("Meera", 85);
        f1.printIdCard();
        f2.printIdCard();
        FixedSrmStudent.printTotalAdmissions();
    }
}

// BROKEN: every field is static, so all instances share the SAME fields.
// - name: static means there is only one "name" slot shared by every
//   student object; creating a second student overwrites the first one's name.
// - regNo: same problem — every student ends up sharing one regNo.
// - attendance: same problem — every student ends up sharing one attendance value.
// None of these fields represent something shared across the whole class;
// they represent per-student data, so they must be instance fields.
class BrokenSrmStudent {
    static String name;
    static String regNo;
    static int attendance;

    public BrokenSrmStudent(String name, String regNo, int attendance) {
        BrokenSrmStudent.name = name;
        BrokenSrmStudent.regNo = regNo;
        BrokenSrmStudent.attendance = attendance;
    }
}

class FixedSrmStudent {
    String name;
    String regNo;
    int attendance;

    static String university = "SRM";
    static int admissionCount = 0;

    public FixedSrmStudent(String name, int attendance) {
        admissionCount++;
        this.name = name;
        this.regNo = "RA23110030101" + admissionCount;
        this.attendance = attendance;
    }

    void printIdCard() {
        System.out.println(name + " | " + regNo);
    }

    static void printTotalAdmissions() {
        System.out.println("Students admitted so far: " + admissionCount);
    }
}
