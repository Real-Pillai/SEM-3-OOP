public class FeeHostelMiniSystem {

    public static void main(String[] args) {
        SrmStudent ravi = new SrmStudent("Ravi", "R1", new HostelFeeAccount("R1", 200000, 0));
        SrmStudent anitha = new SrmStudent("Anitha", "R2", new HostelFeeAccount("R2", 180000, 0));
        SrmStudent karthik = new SrmStudent("Karthik", "R3", new HostelFeeAccount("R3", 200000, 0));

        ravi.room = new HostelRoom("C-214", 3, 2);
        anitha.room = new HostelRoom("C-507", 2, 1);
        // karthik intentionally left unallotted

        ravi.feeAccount.pay(60000);
        anitha.feeAccount.pay(0); // will demonstrate a rejected payment below
        anitha.feeAccount.pay(-5000); // rejected — non-positive
        karthik.feeAccount.pay(0);

        System.out.println(ravi.fullStatus());
        System.out.println(anitha.fullStatus());
        System.out.println(karthik.fullStatus());

        System.out.println("Total students: " + SrmStudent.totalStudents);
    }
}

class FeeAccount {
    private String regNo;
    private double totalFee;
    private double amountPaid;

    public FeeAccount(String regNo, double totalFee, double amountPaid) {
        this.regNo = regNo;
        this.totalFee = totalFee;
        this.amountPaid = amountPaid;
    }

    public void pay(double amount) {
        if (amount <= 0) return;
        amountPaid += amount;
    }

    public double getDue() {
        return totalFee - amountPaid;
    }
}

class HostelFeeAccount extends FeeAccount {
    public HostelFeeAccount(String regNo, double totalFee, double amountPaid) {
        super(regNo, totalFee, amountPaid);
    }
}

class HostelRoom {
    String roomNo;
    int beds;
    int occupied;

    public HostelRoom(String roomNo, int beds, int occupied) {
        this.roomNo = roomNo;
        this.beds = beds;
        this.occupied = occupied;
    }

    void allot(String name) {
        if (occupied < beds) occupied++;
    }
}

class SrmStudent {
    String name;
    String regNo;
    HostelFeeAccount feeAccount;
    HostelRoom room;

    static int totalStudents = 0;

    public SrmStudent(String name, String regNo, HostelFeeAccount feeAccount) {
        this.name = name;
        this.regNo = regNo;
        this.feeAccount = feeAccount;
        totalStudents++;
    }

    String fullStatus() {
        String roomStr = (room == null) ? "unallotted" : room.roomNo;
        return name + " | Due: Rs " + feeAccount.getDue() + " | Room: " + roomStr;
    }
}
