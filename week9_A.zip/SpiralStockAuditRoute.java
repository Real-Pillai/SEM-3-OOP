import java.util.ArrayList;
import java.util.List;

public class SpiralStockAuditRoute {

    // Time complexity: O(m * n) -- every bin is visited exactly once.
    // Additional space complexity: O(1) excluding the output list (just four boundary
    // variables: top, bottom, left, right).
    static List<Integer> auditRoute(int[][] grid) {
        List<Integer> result = new ArrayList<>();
        if (grid.length == 0 || grid[0].length == 0) return result;

        int top = 0, bottom = grid.length - 1;
        int left = 0, right = grid[0].length - 1;

        while (top <= bottom && left <= right) {
            // traverse top row, left to right
            for (int col = left; col <= right; col++) {
                result.add(grid[top][col]);
            }
            top++;

            // traverse right column, top to bottom
            for (int row = top; row <= bottom; row++) {
                result.add(grid[row][right]);
            }
            right--;

            // traverse bottom row, right to left (only if a row remains)
            if (top <= bottom) {
                for (int col = right; col >= left; col--) {
                    result.add(grid[bottom][col]);
                }
                bottom--;
            }

            // traverse left column, bottom to top (only if a column remains)
            if (left <= right) {
                for (int row = bottom; row >= top; row--) {
                    result.add(grid[row][left]);
                }
                left++;
            }
        }

        return result;
    }

    public static void main(String[] args) {
        int[][] grid = {
                {1, 2, 3, 4},
                {5, 6, 7, 8},
                {9, 10, 11, 12}
        };

        System.out.println(auditRoute(grid));
    }
}
