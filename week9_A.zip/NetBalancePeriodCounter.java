import java.util.HashMap;
import java.util.Map;

public class NetBalancePeriodCounter {

    // Brute-force (summing every subarray): O(n^2) time, O(1) extra space.
    // Optimized: a running prefix sum combined with a hash map of
    // "how many times has this prefix sum occurred so far" runs in O(n) time,
    // O(n) additional space. At each index j with running total S, a period
    // ending at j sums to k exactly when an earlier prefix sum equaled S - k,
    // so we look that value up in the map (O(1) average) and add its count.
    static int countPeriods(int[] transactions, long k) {
        Map<Long, Integer> prefixCount = new HashMap<>();
        prefixCount.put(0L, 1); // empty prefix, to handle periods starting at index 0

        long runningSum = 0;
        int count = 0;

        for (int value : transactions) {
            runningSum += value;
            long needed = runningSum - k;
            count += prefixCount.getOrDefault(needed, 0);
            prefixCount.put(runningSum, prefixCount.getOrDefault(runningSum, 0) + 1);
        }

        return count;
    }

    public static void main(String[] args) {
        int[] transactions1 = {3, 4, -7, 1, 3, 3, 1, -4};
        System.out.println(countPeriods(transactions1, 7));

        int[] transactions2 = {1, 2, 3};
        System.out.println(countPeriods(transactions2, 10));
    }
}
