public class LongestBudgetFriendlyStreak {

    // Brute-force (checking every possible run): O(n^2) -- or O(n^3) if each sum is
    // recomputed from scratch for every (start, end) pair.
    // Optimized: a variable-size sliding window runs in O(n) time, O(1) additional space.
    // Non-negative costs are essential: they guarantee that extending the window to the
    // right can only increase (or keep equal) the running sum, and shrinking from the
    // left can only decrease (or keep equal) it. That monotonic behavior is exactly what
    // lets the left pointer advance only forward and never needs to revisit -- with
    // negative values the sum could drop and rise unpredictably, breaking the two-pointer
    // invariant entirely.
    static int[] longestStreak(int[] costs, long budget) {
        int n = costs.length;
        int left = 0;
        long sum = 0;
        int bestLength = 0;
        int bestStart = -1;

        for (int right = 0; right < n; right++) {
            sum += costs[right];
            while (sum > budget) {
                sum -= costs[left];
                left++;
            }
            int currentLength = right - left + 1;
            if (currentLength > bestLength) {
                bestLength = currentLength;
                bestStart = left;
            }
        }

        if (bestLength == 0) {
            return new int[]{0, -1};
        }
        return new int[]{bestLength, bestStart};
    }

    public static void main(String[] args) {
        int[] costs1 = {4, 2, 1, 7, 3, 1, 2, 1, 5};
        int[] result1 = longestStreak(costs1, 8);
        System.out.println("(" + result1[0] + ", " + result1[1] + ")");

        int[] costs2 = {9, 10};
        int[] result2 = longestStreak(costs2, 8);
        System.out.println("(" + result2[0] + ", " + result2[1] + ")");
    }
}
