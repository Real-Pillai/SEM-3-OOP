import java.util.ArrayList;
import java.util.List;

public class MallFootfallRangeReport {

    // Naive approach: O(q * n) worst case -- summing the range from scratch for every query.
    // Optimized: O(n) one-time preprocessing to build a prefix-sum array, then O(1) per query,
    // so q queries cost O(n + q) total. Additional space: O(n) for the prefix array.
    // The preprocessing cost is worth paying whenever the same array is queried more than a
    // handful of times (here, up to 10^5 queries against one day's data) -- the one-time O(n)
    // setup is quickly amortized away.
    static List<Integer> footfallReport(int[] visitors, int[][] queries) {
        int n = visitors.length;
        int[] prefix = new int[n + 1];
        for (int i = 0; i < n; i++) {
            prefix[i + 1] = prefix[i] + visitors[i];
        }

        List<Integer> results = new ArrayList<>();
        for (int[] q : queries) {
            int start = q[0], end = q[1];
            results.add(prefix[end + 1] - prefix[start]);
        }
        return results;
    }

    public static void main(String[] args) {
        int[] visitors = {12, 7, 3, 9, 15, 4, 8};
        int[][] queries = {{0, 2}, {2, 5}, {4, 6}, {3, 3}};

        List<Integer> result = footfallReport(visitors, queries);
        System.out.println(result);
    }
}
