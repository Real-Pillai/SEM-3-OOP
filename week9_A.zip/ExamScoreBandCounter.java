public class ExamScoreBandCounter {

    // Linear scan: O(n) time, O(1) space.
    // Optimized (binary search on a sorted array): O(log n) time, O(1) additional space.
    // Duplicates at the band edges matter because a plain binary search just finds *some*
    // matching index and stops -- it doesn't tell you how many equal values surround it.
    // The fix is to search for BOUNDARIES instead of a single match: the first position
    // where score >= low (a "lower bound"), and the first position where score > high
    // (an "upper bound" just past the band). The count in the band is simply the
    // difference between those two boundary indices, which correctly includes every
    // duplicate at both ends of the range.
    static int countInBand(int[] scores, int low, int high) {
        int firstAtLeastLow = lowerBound(scores, low);
        int firstAboveHigh = lowerBound(scores, high + 1);
        return firstAboveHigh - firstAtLeastLow;
    }

    // Returns the index of the first element >= target (or scores.length if none).
    private static int lowerBound(int[] scores, int target) {
        int lo = 0, hi = scores.length;
        while (lo < hi) {
            int mid = lo + (hi - lo) / 2;
            if (scores[mid] < target) {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        return lo;
    }

    public static void main(String[] args) {
        int[] scores = {35, 42, 42, 50, 58, 58, 58, 63, 71, 88};

        System.out.println(countInBand(scores, 42, 58));
        System.out.println(countInBand(scores, 90, 100));
    }
}
