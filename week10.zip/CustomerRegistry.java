import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class CustomerRegistry {

    public static void main(String[] args) {
        CustomerRegistrySystem registry = new CustomerRegistrySystem();

        System.out.println(registry.add(new Customer(101, "Asha"))); // from Branch A
        System.out.println(registry.add(new Customer(101, "Asha")) ? "true" : "false (duplicate rejected)");
        System.out.println(registry.add(new Customer(102, "Ravi")));

        System.out.println("unique count " + registry.uniqueCount());
        System.out.println("contains: " + registry.contains(new Customer(101, "Asha")));
    }
}

// equals()/hashCode() are overridden together so two Customer objects
// representing the same real-world customer (same id and name) are
// treated as equal and hash to the same bucket -- required for correct
// behavior in a HashSet or as a HashMap key.
class Customer {
    private int id;
    private String name;

    public Customer(int id, String name) {
        this.id = id;
        this.name = name;
    }

    int getId() {
        return id;
    }

    String getName() {
        return name;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Customer)) return false;
        Customer other = (Customer) obj;
        return id == other.id && Objects.equals(name, other.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name);
    }
}

class CustomerRegistrySystem {
    private Set<Customer> customers = new HashSet<>();

    boolean add(Customer customer) {
        return customers.add(customer); // Set.add returns false for a duplicate
    }

    boolean contains(Customer customer) {
        return customers.contains(customer);
    }

    int uniqueCount() {
        return customers.size();
    }
}
