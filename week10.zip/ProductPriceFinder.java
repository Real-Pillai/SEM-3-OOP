public class ProductPriceFinder {

    static int lowerBound(int[] prices, int target) {
        int lo = 0, hi = prices.length;
        while (lo < hi) {
            int mid = lo + (hi - lo) / 2;
            if (prices[mid] < target) {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        return lo;
    }

    static int upperBound(int[] prices, int target) {
        int lo = 0, hi = prices.length;
        while (lo < hi) {
            int mid = lo + (hi - lo) / 2;
            if (prices[mid] <= target) {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        return lo;
    }

    static int countInRange(int[] prices, int low, int high) {
        int lowerIndex = lowerBound(prices, low);
        int upperIndex = upperBound(prices, high);
        return upperIndex - lowerIndex;
    }

    public static void main(String[] args) {
        int[] prices = {100, 150, 150, 200, 300, 450};
        int low = 150, high = 300;

        int lowerIndex = lowerBound(prices, low);
        int upperIndex = upperBound(prices, high);
        int count = countInRange(prices, low, high);

        System.out.println("Lower bound index " + lowerIndex);
        System.out.println("Upper bound index " + upperIndex);
        System.out.println("Count " + count);
    }
}
