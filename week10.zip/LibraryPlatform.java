import java.util.ArrayList;
import java.util.List;

public class LibraryPlatform {

    public static void main(String[] args) {
        LibrarySystem library = new LibrarySystem();

        System.out.println(library.add(new Book("B1")) ? "B1 added" : "duplicate rejected");
        System.out.println(library.add(new Book("B1")) ? "B1 added" : "duplicate rejected");
        System.out.println(library.add(new EBook("E1")) ? "E1 added" : "duplicate rejected");

        library.reserve("B1", "M1");
        library.download("B1");
        library.download("E1");

        int index = library.findIndexById("E1");
        System.out.println("E1 found at index " + index);
    }
}

interface Reservable {
    void reserve(String memberId);
}

interface Downloadable {
    void download();
}

abstract class Resource implements Comparable<Resource> {
    protected String id;

    public Resource(String id) {
        this.id = id;
    }

    String getId() {
        return id;
    }

    @Override
    public int compareTo(Resource other) {
        return this.id.compareTo(other.id);
    }
}

class Book extends Resource implements Reservable {
    public Book(String id) {
        super(id);
    }

    @Override
    public void reserve(String memberId) {
        System.out.println(id + " reserved for " + memberId);
    }
}

class EBook extends Resource implements Downloadable {
    public EBook(String id) {
        super(id);
    }

    @Override
    public void download() {
        System.out.println(id + " downloaded");
    }
}

// Resources are stored in an array (kept sorted by ID) as the task
// specifies, rather than a map, so lookups and the "ordered by ID"
// requirement are both demonstrated explicitly.
class LibrarySystem {
    private Resource[] resources = new Resource[0];

    boolean add(Resource resource) {
        if (findIndexById(resource.getId()) != -1) {
            return false; // duplicate
        }
        Resource[] updated = new Resource[resources.length + 1];
        int insertAt = 0;
        while (insertAt < resources.length && resources[insertAt].getId().compareTo(resource.getId()) < 0) {
            updated[insertAt] = resources[insertAt];
            insertAt++;
        }
        updated[insertAt] = resource;
        for (int i = insertAt; i < resources.length; i++) {
            updated[i + 1] = resources[i];
        }
        resources = updated;
        return true;
    }

    void reserve(String id, String memberId) {
        Resource r = findById(id);
        if (r instanceof Reservable) {
            ((Reservable) r).reserve(memberId);
        } else {
            System.out.println(id + " rejected: reserve unsupported");
        }
    }

    void download(String id) {
        Resource r = findById(id);
        if (r instanceof Downloadable) {
            ((Downloadable) r).download();
        } else {
            System.out.println(id + " rejected: download unsupported");
        }
    }

    Resource findById(String id) {
        int index = findIndexById(id);
        return index == -1 ? null : resources[index];
    }

    int findIndexById(String id) {
        for (int i = 0; i < resources.length; i++) {
            if (resources[i].getId().equals(id)) return i;
        }
        return -1;
    }
}
