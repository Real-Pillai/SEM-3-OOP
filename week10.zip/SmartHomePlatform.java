import java.util.LinkedHashMap;
import java.util.Map;

public class SmartHomePlatform {

    public static void main(String[] args) {
        SmartHomeSystem system = new SmartHomeSystem();

        system.addDevice(new Light("L1"));
        system.addDevice(new Fan("F1"));
        system.addDevice(new Plug("P1", 12));

        system.executeOn("L1");
        system.executeDim("L1", 40);
        system.executeDim("F1", 30);
        system.executeSchedule("F1", "22:00");
        system.executeEnergy("P1");
        system.executeEnergy("L1");
    }
}

// Capability interfaces: a device implements only the ones it supports,
// so the system can reject a command simply by checking instanceof.
interface Dimmable {
    void dim(int level);
}

interface Schedulable {
    void schedule(String time);
}

interface EnergyMonitorable {
    String getEnergyReport();
}

abstract class Device {
    protected String id;
    protected boolean on = false;

    public Device(String id) {
        this.id = id;
    }

    String getId() {
        return id;
    }

    void turnOn() {
        on = true;
    }

    void turnOff() {
        on = false;
    }
}

class Light extends Device implements Dimmable, Schedulable {
    private int brightness = 0;
    private String scheduledTime;

    public Light(String id) {
        super(id);
    }

    @Override
    public void dim(int level) {
        brightness = level;
    }

    @Override
    public void schedule(String time) {
        scheduledTime = time;
    }
}

class Fan extends Device implements Schedulable {
    private String scheduledTime;

    public Fan(String id) {
        super(id);
    }

    @Override
    public void schedule(String time) {
        scheduledTime = time;
    }
}

class Plug extends Device implements EnergyMonitorable {
    private double energyKwh;

    public Plug(String id, double energyKwh) {
        super(id);
        this.energyKwh = energyKwh;
    }

    @Override
    public String getEnergyReport() {
        return energyKwh + " kWh";
    }
}

class SmartHomeSystem {
    private Map<String, Device> devices = new LinkedHashMap<>();

    void addDevice(Device device) {
        devices.put(device.getId(), device);
    }

    void executeOn(String id) {
        Device d = devices.get(id);
        d.turnOn();
        System.out.println(id + " is ON");
    }

    void executeDim(String id, int level) {
        Device d = devices.get(id);
        if (d instanceof Dimmable) {
            ((Dimmable) d).dim(level);
            System.out.println(id + " dimmed to " + level);
        } else {
            System.out.println(id + " rejected: DIM unsupported");
        }
    }

    void executeSchedule(String id, String time) {
        Device d = devices.get(id);
        if (d instanceof Schedulable) {
            ((Schedulable) d).schedule(time);
            System.out.println(id + " scheduled " + time);
        } else {
            System.out.println(id + " rejected: SCHEDULE unsupported");
        }
    }

    void executeEnergy(String id) {
        Device d = devices.get(id);
        if (d instanceof EnergyMonitorable) {
            System.out.println(id + " energy " + ((EnergyMonitorable) d).getEnergyReport());
        } else {
            System.out.println(id + " rejected: ENERGY unsupported");
        }
    }
}
