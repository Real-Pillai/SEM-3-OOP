import java.util.LinkedHashMap;
import java.util.Map;

public class StudentMarksGrid {

    public static void main(String[] args) {
        String[] subjects = {"Math", "Sci", "Eng"};
        MarksSystem system = new MarksSystem(subjects);

        system.addStudent("Anu", new Integer[]{80, 90, 70});
        system.addStudent("Ravi", new Integer[]{60, 85, null}); // missing Eng
        system.addStudent("Meena", new Integer[]{95, 75, 88});

        StringBuilder totalsLine = new StringBuilder("Totals ");
        Map<String, Integer> totals = system.calculateTotals();
        int i = 0;
        for (Map.Entry<String, Integer> entry : totals.entrySet()) {
            totalsLine.append(entry.getKey()).append(" ").append(entry.getValue());
            if (i < totals.size() - 1) totalsLine.append(", ");
            i++;
        }
        System.out.println(totalsLine);

        StringBuilder toppersLine = new StringBuilder("toppers ");
        String[] toppersInfo = system.findToppers();
        for (int j = 0; j < toppersInfo.length; j++) {
            toppersLine.append(toppersInfo[j]);
            if (j < toppersInfo.length - 1) toppersLine.append(", ");
        }
        System.out.println(toppersLine);
    }
}

// Marks are stored as a map of student name -> array of Integer (boxed so
// a missing mark can be represented as null instead of a sentinel value).
class MarksSystem {
    private String[] subjects;
    private Map<String, Integer[]> marksByStudent = new LinkedHashMap<>();

    public MarksSystem(String[] subjects) {
        this.subjects = subjects;
    }

    void addStudent(String name, Integer[] marks) {
        marksByStudent.put(name, marks);
    }

    Map<String, Integer> calculateTotals() {
        Map<String, Integer> totals = new LinkedHashMap<>();
        for (Map.Entry<String, Integer[]> entry : marksByStudent.entrySet()) {
            int total = 0;
            for (Integer mark : entry.getValue()) {
                if (mark != null) total += mark;
            }
            totals.put(entry.getKey(), total);
        }
        return totals;
    }

    String[] findToppers() {
        String[] result = new String[subjects.length];
        for (int subjIndex = 0; subjIndex < subjects.length; subjIndex++) {
            int maxMark = -1;
            String topper = null;
            for (Map.Entry<String, Integer[]> entry : marksByStudent.entrySet()) {
                Integer[] marks = entry.getValue();
                if (subjIndex < marks.length && marks[subjIndex] != null && marks[subjIndex] > maxMark) {
                    maxMark = marks[subjIndex];
                    topper = entry.getKey();
                }
            }
            result[subjIndex] = subjects[subjIndex] + " " + topper + " " + maxMark;
        }
        return result;
    }
}
