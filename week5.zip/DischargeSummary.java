import java.util.Arrays;

public class DischargeSummary {
    private final String patientId;
    private final String[] medicationCodes;

    static {
        // one-time shared setup
    }

    public DischargeSummary(String patientId, String[] medicationCodes) {
        for (String code : medicationCodes) {
            if (!isValidCode(code)) {
                throw new IllegalArgumentException("Invalid medication code: " + code);
            }
        }
        this.patientId = patientId;
        this.medicationCodes = Arrays.copyOf(medicationCodes, medicationCodes.length);
    }

    private static boolean isValidCode(String code) {
        if (code == null) return false;
        if (!code.startsWith("MED-")) return false;
        if (code.length() != 5) return false;
        char c = code.charAt(4);
        return Character.isUpperCase(c);
    }

    public String getPatientId() {
        return patientId;
    }

    public String[] getMedicationCodes() {
        return Arrays.copyOf(medicationCodes, medicationCodes.length);
    }

    public DischargeSummary withCorrectedMedication(int index, String newCode) {
        String[] updated = Arrays.copyOf(medicationCodes, medicationCodes.length);
        updated[index] = newCode;
        return new DischargeSummary(this.patientId, updated);
    }

    static String processNightlyBatch(DischargeSummary[] summaries) {
        int processed = 0, nullSkipped = 0, critical = 0, routine = 0;
        for (DischargeSummary s : summaries) {
            if (s == null) {
                nullSkipped++;
                continue;
            }
            processed++;
            if (s instanceof CriticalCareDischargeSummary) {
                critical++;
            } else {
                routine++;
            }
        }
        return processed + " processed | " + nullSkipped + " null skipped | " + critical + " critical-care | " + routine + " routine";
    }

    public static void main(String[] args) {
        try {
            new DischargeSummary("MT2026-0142", new String[]{"MED-A", "bad"});
            System.out.println("construction succeeded");
        } catch (IllegalArgumentException e) {
            System.out.println("construction rejected");
        }

        DischargeSummary d = new DischargeSummary("MT2026-0142", new String[]{"MED-A", "MED-B"});
        String[] codes = d.getMedicationCodes();
        codes[0] = "TAMPERED";
        System.out.println(d.getMedicationCodes()[0]);

        DischargeSummary[] batch = new DischargeSummary[]{
                new CriticalCareDischargeSummary("MT001", new String[]{"MED-X"}, 4),
                null,
                new DischargeSummary("MT002", new String[]{"MED-Y"})
        };
        System.out.println(processNightlyBatch(batch));
    }
}

final class CriticalCareDischargeSummary extends DischargeSummary {
    private final int icuDays;

    public CriticalCareDischargeSummary(String patientId, String[] medicationCodes, int icuDays) {
        super(patientId, medicationCodes);
        this.icuDays = icuDays;
    }

    public int getIcuDays() {
        return icuDays;
    }
}
