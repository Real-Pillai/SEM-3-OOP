public class UniversalMediaLauncher {

    static void launchAll(Playable[] items) {
        for (Playable item : items) {
            System.out.println(item.play());
        }
    }

    public static void main(String[] args) {
        AudioFile a = new AudioFile("Morning Jazz");
        System.out.println(a.play());
        System.out.println(a.play(30));
        System.out.println(a.getFormatInfo());

        Podcast p = new Podcast("Tech Talk", 12);
        System.out.println(p.play());

        Playable ref = a; // upcasting: AudioFile reference stored as the Playable interface type
        launchAll(new Playable[]{ref, p});
    }
}

interface Playable {
    String play();
    String play(int fromSecond);
    String pause();
}

abstract class MediaFile {
    private final String fileId;
    private static int fileCounter = 0;

    public MediaFile() {
        fileCounter++;
        this.fileId = "MF-" + (1000 + fileCounter);
    }

    public abstract String getFormatInfo();

    String getFileId() {
        return fileId;
    }
}

class AudioFile extends MediaFile implements Playable {
    private String title;

    public AudioFile(String title) {
        this.title = title;
    }

    @Override
    public String play() {
        return "Playing audio: " + title;
    }

    @Override
    public String play(int fromSecond) {
        int minutes = fromSecond / 60;
        int seconds = fromSecond % 60;
        return "Playing audio: " + title + " from " + minutes + ":" + String.format("%02d", seconds);
    }

    @Override
    public String pause() {
        return "Paused: " + title;
    }

    @Override
    public String getFormatInfo() {
        return "Audio file, ID: " + getFileId();
    }
}

class Podcast implements Playable {
    private String showName;
    private int episodeNumber;

    public Podcast(String showName, int episodeNumber) {
        this.showName = showName;
        this.episodeNumber = episodeNumber;
    }

    @Override
    public String play() {
        return "Streaming episode " + episodeNumber + " of " + showName;
    }

    @Override
    public String play(int fromSecond) {
        return "Streaming episode " + episodeNumber + " of " + showName + " from " + fromSecond + "s";
    }

    @Override
    public String pause() {
        return "Paused episode " + episodeNumber + " of " + showName;
    }
}

// Justification: AudioFile is a MediaFile (IS-A) because it genuinely has
// shared media-file properties (a fileId, a format) that make sense to
// track alongside every other stored media file. Podcast is only a
// Playable (CAN-DO) because it is streamed live and manages its own
// episode data independently -- it would gain nothing from a fileId or
// getFormatInfo() and forcing it into the MediaFile hierarchy would be
// an artificial relationship.
