public class DrawingCanvas {

    static void printArea(Shape s) {
        System.out.println(s.calculateArea());
    }

    public static void main(String[] args) {
        CircleShape c = new CircleShape(5.0);
        System.out.println(c.calculateArea());

        SquareShape sq = new SquareShape(4.0);
        System.out.println(sq.calculateArea());

        sq.scale(2.0);
        System.out.println(sq.calculateArea());

        printArea(c);
    }
}

abstract class Shape {
    private final String shapeId;
    private static int shapeCounter = 0;

    public Shape() {
        shapeCounter++;
        this.shapeId = "SHP-" + shapeCounter;
    }

    public abstract double calculateArea();

    void scale(double factor) {
        scale(factor, factor);
    }

    abstract void scale(double xFactor, double yFactor);

    String getShapeId() {
        return shapeId;
    }
}

class CircleShape extends Shape {
    private double radius;

    public CircleShape(double radius) {
        this.radius = radius;
    }

    @Override
    public double calculateArea() {
        return Math.PI * radius * radius;
    }

    @Override
    void scale(double xFactor, double yFactor) {
        radius *= ((xFactor + yFactor) / 2.0);
    }
}

class SquareShape extends Shape {
    private double side;

    public SquareShape(double side) {
        this.side = side;
    }

    @Override
    public double calculateArea() {
        return side * side;
    }

    @Override
    void scale(double xFactor, double yFactor) {
        side *= ((xFactor + yFactor) / 2.0);
    }
}
