public class PalindromeChecker {

    static boolean isPalindromeIterative(String text) {
        int left = 0, right = text.length() - 1;
        while (left < right) {
            if (text.charAt(left) != text.charAt(right)) return false;
            left++;
            right--;
        }
        return true;
    }

    static boolean isPalindromeRecursive(String text) {
        if (text.length() <= 1) return true;
        if (text.charAt(0) != text.charAt(text.length() - 1)) return false;
        return isPalindromeRecursive(text.substring(1, text.length() - 1));
    }

    static boolean isPalindromeArrayReversal(String text) {
        char[] arr = text.toCharArray();
        int n = arr.length;
        char[] reversed = new char[n];
        for (int i = 0; i < n; i++) reversed[i] = arr[n - 1 - i];
        return new String(reversed).equals(text);
    }

    static String result(boolean b) {
        return b ? "Palindrome" : "Not Palindrome";
    }

    public static void main(String[] args) {
        String[] inputs = {"madam", "hello"};
        for (String s : inputs) {
            System.out.println("\"" + s + "\" -> Iterative: " + result(isPalindromeIterative(s)) +
                    " | Recursive: " + result(isPalindromeRecursive(s)) +
                    " | Array Reversal: " + result(isPalindromeArrayReversal(s)));
        }
    }
}
