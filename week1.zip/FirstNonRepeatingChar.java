import java.util.HashMap;
import java.util.Map;

public class FirstNonRepeatingChar {

    static Character findFirstNonRepeatingChar(String text) {
        Map<Character, Integer> freq = new HashMap<>();
        for (char c : text.toCharArray()) {
            freq.put(c, freq.getOrDefault(c, 0) + 1);
        }
        for (char c : text.toCharArray()) {
            if (freq.get(c) == 1) return c;
        }
        return null;
    }

    public static void main(String[] args) {
        String[] inputs = {"swiss", "aabbcc"};
        for (String s : inputs) {
            Character result = findFirstNonRepeatingChar(s);
            if (result != null) {
                System.out.println("\"" + s + "\" -> First Non-Repeating Character: '" + result + "'");
            } else {
                System.out.println("\"" + s + "\" -> No Non-Repeating Character Found");
            }
        }
    }
}
