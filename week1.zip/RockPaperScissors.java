import java.util.Random;

public class RockPaperScissors {
    static String playRound(String playerMove, String computerMove) {
        if (playerMove.equalsIgnoreCase(computerMove)) return "Draw";
        switch (playerMove.toLowerCase()) {
            case "rock": return computerMove.equalsIgnoreCase("scissors") ? "Player Wins" : "Computer Wins";
            case "paper": return computerMove.equalsIgnoreCase("rock") ? "Player Wins" : "Computer Wins";
            case "scissors": return computerMove.equalsIgnoreCase("paper") ? "Player Wins" : "Computer Wins";
            default: return "Invalid";
        }
    }

    public static void main(String[] args) {
        String[] moves = {"Rock", "Paper", "Scissors"};
        String[] playerMoves = {"Rock", "Paper", "Scissors", "Rock", "Paper"};
        int n = playerMoves.length;
        String[] compMoves = new String[n];
        String[] results = new String[n];
        Random rand = new Random();

        int wins = 0, losses = 0, draws = 0;

        for (int i = 0; i < n; i++) {
            compMoves[i] = moves[rand.nextInt(3)];
            results[i] = playRound(playerMoves[i], compMoves[i]);
            if (results[i].equals("Player Wins")) wins++;
            else if (results[i].equals("Computer Wins")) losses++;
            else draws++;
        }

        System.out.println("Round | Player Move | Computer Move | Result");
        for (int i = 0; i < n; i++) {
            System.out.println((i + 1) + " | " + playerMoves[i] + " | " + compMoves[i] + " | " + results[i]);
        }

        double winPct = (wins * 100.0) / n;
        System.out.println("\nFinal Summary");
        System.out.println("Wins: " + wins + " | Losses: " + losses + " | Draws: " + draws + " | Win % = " + winPct + "%");
    }
}
