public class LibraryCatalogLookup {

    // Binary search on the sorted ISBN catalog: O(log n) time per query, O(1) additional
    // space. This is appropriate because queries vastly outnumber updates: paying a
    // one-time O(n log n) sort cost (or simply maintaining sorted order on the rare
    // insert) is easily worth it when every one of the many subsequent lookups drops
    // from O(n) (linear scan) to O(log n).
    static String findBook(String[][] catalog, String targetIsbn) {
        int lo = 0, hi = catalog.length - 1;

        while (lo <= hi) {
            int mid = lo + (hi - lo) / 2;
            int cmp = catalog[mid][0].compareTo(targetIsbn);
            if (cmp == 0) {
                return catalog[mid][1];
            } else if (cmp < 0) {
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }

        return "Not Found";
    }

    public static void main(String[] args) {
        String[][] catalog = {
                {"0001112223", "Introduction to Algebra"},
                {"0002223334", "Beginning Python"},
                {"0003334445", "Classic Mythology"},
                {"0004445556", "Data and Society"},
                {"0005556667", "European History"}
        };

        System.out.println(findBook(catalog, "0003334445"));
        System.out.println(findBook(catalog, "0009998887"));
    }
}
