public class WarehouseBinGridScan {

    // Time complexity: O(m * n), where m = rows and n = columns -- every cell must be
    // visited once. Additional space complexity: O(1) (excluding the input grid itself),
    // just a running total and the current best value/coordinates.
    static Object[] warehouseSummary(int[][] grid) {
        int total = 0;
        int maxValue = Integer.MIN_VALUE;
        int maxRow = -1, maxCol = -1;

        for (int row = 0; row < grid.length; row++) {
            for (int col = 0; col < grid[row].length; col++) {
                int value = grid[row][col];
                total += value;
                if (value > maxValue) {
                    maxValue = value;
                    maxRow = row;
                    maxCol = col;
                }
            }
        }

        return new Object[]{total, new int[]{maxRow, maxCol}};
    }

    public static void main(String[] args) {
        int[][] grid = {
                {4, 9, 2},
                {7, 1, 6},
                {3, 12, 5}
        };

        Object[] result = warehouseSummary(grid);
        int total = (int) result[0];
        int[] coord = (int[]) result[1];
        System.out.println("total = " + total + ", maxCoordinate = (" + coord[0] + ", " + coord[1] + ")");
    }
}
