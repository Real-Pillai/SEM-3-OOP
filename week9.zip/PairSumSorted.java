public class PairSumSorted {

    // Two-pointer approach on a sorted array: O(n) time, O(1) additional space.
    // A solution ignoring the sorted property (e.g., a nested loop checking every pair,
    // or even a hash-set approach with no sorted order to exploit) still needs O(n^2)
    // time for brute force, or O(n) time / O(n) space with a hash set. The two-pointer
    // technique matches the hash-set's O(n) time but needs no extra space at all,
    // because the sorted order itself tells us which pointer to move.
    static Object pairSumSorted(int[] nums, int target) {
        int left = 0, right = nums.length - 1;

        while (left < right) {
            int sum = nums[left] + nums[right];
            if (sum == target) {
                return new int[]{nums[left], nums[right]};
            } else if (sum < target) {
                left++;
            } else {
                right--;
            }
        }

        return "Not Found";
    }

    public static void main(String[] args) {
        int[] nums1 = {-4, -1, 0, 3, 5, 9};
        Object result1 = pairSumSorted(nums1, 4);
        printResult(result1);

        int[] nums2 = {1, 2, 3};
        Object result2 = pairSumSorted(nums2, 100);
        printResult(result2);
    }

    static void printResult(Object result) {
        if (result instanceof int[]) {
            int[] pair = (int[]) result;
            System.out.println("(" + pair[0] + ", " + pair[1] + ")");
        } else {
            System.out.println("\"" + result + "\"");
        }
    }
}
