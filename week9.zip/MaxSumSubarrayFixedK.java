public class MaxSumSubarrayFixedK {

    // Naive approach (recomputing the sum of each k-sized window from scratch):
    // O(n * k) time, O(1) space.
    // Optimized (sliding window): maintain a running sum and update it in O(1) per
    // slide -- subtract the element leaving the window on the left, add the element
    // entering on the right -- avoiding redundant recomputation entirely.
    // Final solution: O(n) time, O(1) additional space.
    static int maxSumSubarray(int[] sales, int k) {
        int windowSum = 0;
        for (int i = 0; i < k; i++) {
            windowSum += sales[i];
        }

        int maxSum = windowSum;
        for (int i = k; i < sales.length; i++) {
            windowSum += sales[i] - sales[i - k];
            maxSum = Math.max(maxSum, windowSum);
        }

        return maxSum;
    }

    public static void main(String[] args) {
        int[] sales = {2, 1, 5, 1, 3, 2};
        System.out.println(maxSumSubarray(sales, 3));
    }
}
