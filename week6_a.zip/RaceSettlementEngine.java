public class RaceSettlementEngine {

    public static void main(String[] args) {
        System.out.println(RaceEntry.isValidDiscountCode("M123A"));
        System.out.println(RaceEntry.isValidDiscountCode("M12A"));
        System.out.println(RaceEntry.isValidDiscountCode("X123A"));

        RaceEntry r = new RaceEntry("BIB6001", 100);
        r.pay(10, "UPI");

        EliteRunnerEntry eliteEntry = new EliteRunnerEntry("BIB3001", 150, "Elite Full Marathon", 500);
        RelayTeamEntry relayEntry = new RelayTeamEntry("BIB4001", 300, 4);

        System.out.println(settleNight(new RaceEntry[]{eliteEntry, null, relayEntry}));

        System.out.println(RaceEntry.getBibCounter());
    }

    static String settleNight(RaceEntry[] entries) {
        int processed = 0, nullSkipped = 0, relay = 0, individual = 0;
        for (RaceEntry e : entries) {
            if (e == null) {
                nullSkipped++;
                continue;
            }
            processed++;
            if (e instanceof RelayTeamEntry) {
                relay++;
            } else {
                individual++;
            }
        }
        return processed + " processed | " + nullSkipped + " null skipped | " + relay + " relay | " + individual + " individual";
    }
}

class RaceEntry {
    private final int entryCode;
    protected String bibNumber;
    protected double entryFee;
    private double amountPaid = 0;

    private static int bibCounter = 0;

    public RaceEntry(String bibNumber, double entryFee) {
        bibCounter++;
        this.entryCode = bibCounter;
        this.bibNumber = bibNumber;
        this.entryFee = entryFee;
    }

    static int getBibCounter() {
        return bibCounter;
    }

    void pay(double amount) {
        amountPaid += amount;
    }

    void pay(double amount, String mode) {
        System.out.println("Paying via " + mode);
        pay(amount);
    }

    double getBalanceDue() {
        return entryFee - amountPaid;
    }

    static boolean isValidDiscountCode(String code) {
        if (code == null || code.length() != 5) return false;
        if (code.charAt(0) != 'M') return false;
        if (!Character.isDigit(code.charAt(1))) return false;
        if (!Character.isDigit(code.charAt(2))) return false;
        if (!Character.isDigit(code.charAt(3))) return false;
        if (!Character.isUpperCase(code.charAt(4))) return false;
        return true;
    }
}

class RunnerEntry extends RaceEntry {
    protected String category;

    public RunnerEntry(String bibNumber, double entryFee, String category) {
        super(bibNumber, entryFee);
        this.category = category;
    }
}

class EliteRunnerEntry extends RunnerEntry {
    private double sponsorBonus;

    public EliteRunnerEntry(String bibNumber, double entryFee, String category, double sponsorBonus) {
        super(bibNumber, entryFee, category);
        this.sponsorBonus = sponsorBonus;
    }
}

class RelayTeamEntry extends RaceEntry {
    private int teamSize;

    public RelayTeamEntry(String bibNumber, double entryFee, int teamSize) {
        super(bibNumber, entryFee);
        this.teamSize = teamSize;
    }
}
